import React, { useState } from 'react';
import CodeBlock from '../components/CodeBlock';
import ProgressTracker from '../components/ProgressTracker';

const JsTutorial: React.FC = () => {
  const steps = [
    "Introduction to JavaScript",
    "Variables and Data Types",
    "Functions and Scope",
    "Arrays and Objects",
    "DOM Manipulation",
    "Events and Event Handling",
    "Asynchronous JavaScript"
  ];

  const [currentStep, setCurrentStep] = useState(0);

  const tutorialContent = [
    // Introduction to JavaScript
    <>
      <h2>Introduction to JavaScript</h2>
      <p>
        JavaScript is a high-level, interpreted programming language that is one of the core technologies of the World Wide Web. It allows you to create dynamic and interactive web pages by manipulating the Document Object Model (DOM).
      </p>
      
      <div className="glass p-6 my-6">
        <h3 className="text-xl font-semibold mb-4">Key JavaScript Concepts</h3>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>JavaScript runs on the client-side (in the browser)</li>
          <li>It can also run on the server-side with Node.js</li>
          <li>It's an event-driven, functional, and object-oriented language</li>
          <li>It integrates with HTML and CSS to create dynamic web applications</li>
        </ul>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Adding JavaScript to HTML</h3>
      <p>
        There are three ways to include JavaScript in an HTML document:
      </p>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">1. Inline JavaScript</h4>
      <CodeBlock
        language="html"
        code={`<button onclick="alert('Hello, World!')">Click Me</button>`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">2. Internal JavaScript</h4>
      <CodeBlock
        language="html"
        code={`<!DOCTYPE html>
<html>
<head>
  <title>My Page</title>
</head>
<body>
  <button id="myButton">Click Me</button>

  <script>
    document.getElementById("myButton").addEventListener("click", function() {
      alert("Hello, World!");
    });
  </script>
</body>
</html>`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">3. External JavaScript</h4>
      <CodeBlock
        language="html"
        code={`<!DOCTYPE html>
<html>
<head>
  <title>My Page</title>
  <!-- Can be placed in head with defer attribute -->
  <script src="script.js" defer></script>
</head>
<body>
  <button id="myButton">Click Me</button>
  
  <!-- Or placed at the end of body -->
  <!-- <script src="script.js"></script> -->
</body>
</html>`}
      />
      
      <p>And in the script.js file:</p>
      <CodeBlock
        language="javascript"
        code={`document.getElementById("myButton").addEventListener("click", function() {
  alert("Hello, World!");
});`}
      />
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">Best Practices</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>Use external JavaScript files for better organization and caching</li>
          <li>Place scripts at the bottom of the body or use the <code>defer</code> attribute</li>
          <li>Avoid inline JavaScript when possible for better separation of concerns</li>
          <li>Use modern ES6+ features for cleaner, more maintainable code</li>
        </ul>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">JavaScript Console</h3>
      <p>
        The browser console is an essential tool for JavaScript development. You can access it using the developer tools in your browser (usually by pressing F12 or right-clicking and selecting "Inspect").
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Output to console
console.log("Hello, World!"); // General information
console.warn("This is a warning"); // Warning message
console.error("This is an error"); // Error message

// Debugging
console.table(["apple", "banana", "orange"]); // Display data as a table
console.time("Timer"); // Start a timer
// ... code to measure ...
console.timeEnd("Timer"); // End timer and display time elapsed`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">JavaScript Syntax Basics</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Comments</h4>
      <CodeBlock
        language="javascript"
        code={`// This is a single-line comment

/* This is a 
   multi-line comment */`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Statements</h4>
      <CodeBlock
        language="javascript"
        code={`// Statements end with semicolons (optional but recommended)
let greeting = "Hello";
console.log(greeting);

// Multiple statements can be on one line with semicolons
let a = 1; let b = 2; let c = 3;

// Code blocks are enclosed in curly braces
if (true) {
  console.log("This is a code block");
}`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Case Sensitivity</h4>
      <CodeBlock
        language="javascript"
        code={`// JavaScript is case sensitive
let name = "John";
let Name = "Jane";
// name and Name are different variables`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Hello World Example</h3>
      <p>
        Let's create a simple "Hello World" example:
      </p>
      
      <CodeBlock
        language="html"
        code={`<!DOCTYPE html>
<html>
<head>
  <title>JavaScript Hello World</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      margin-top: 50px;
    }
    #greeting {
      font-size: 24px;
      margin: 20px;
      color: #333;
    }
    button {
      padding: 10px 20px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>JavaScript Hello World</h1>
  <p id="greeting">Click the button below</p>
  <button id="greetButton">Say Hello</button>
  
  <script>
    // Get references to the elements
    const greetingElement = document.getElementById("greeting");
    const greetButton = document.getElementById("greetButton");
    
    // Add a click event listener to the button
    greetButton.addEventListener("click", function() {
      // Change the greeting text
      greetingElement.textContent = "Hello, World!";
      // Change the text color
      greetingElement.style.color = "#4CAF50";
    });
  </script>
</body>
</html>`}
      />
      
      <p>
        This example demonstrates several core JavaScript concepts:
      </p>
      
      <ul className="list-disc list-inside space-y-2 mb-6 text-gray-700 dark:text-gray-300">
        <li>Selecting DOM elements using <code>getElementById</code></li>
        <li>Adding event listeners to respond to user interactions</li>
        <li>Manipulating element content and styles dynamically</li>
      </ul>
      
      <p>
        JavaScript is a versatile language with many features beyond what we've covered in this introduction. As you continue through this tutorial, you'll learn about variables, functions, control structures, and more advanced topics that will allow you to build complex and interactive web applications.
      </p>
    </>,
    
    // Variables and Data Types
    <>
      <h2>Variables and Data Types</h2>
      <p>
        Variables are containers for storing data values. JavaScript is a dynamically typed language, which means variables can hold different types of data throughout your program.
      </p>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Declaring Variables</h3>
      <p>
        There are three ways to declare variables in JavaScript:
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Using var (older way, function-scoped)
var name = "John";

// Using let (block-scoped, can be reassigned)
let age = 30;

// Using const (block-scoped, cannot be reassigned)
const PI = 3.14159;

// Declaring multiple variables at once
let firstName = "John", lastName = "Doe", birthYear = 1990;

// Declaring without assignment (initializes as undefined)
let country;
console.log(country); // undefined`}
      />
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">var vs. let vs. const</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li><strong>var</strong>: Function-scoped, can be redeclared, hoisted</li>
          <li><strong>let</strong>: Block-scoped, cannot be redeclared, not hoisted</li>
          <li><strong>const</strong>: Block-scoped, cannot be reassigned or redeclared, not hoisted</li>
        </ul>
        <p className="mt-4 text-gray-700 dark:text-gray-300">
          In modern JavaScript, prefer <code>const</code> by default, and use <code>let</code> when you need to reassign variables. Avoid <code>var</code> in new code.
        </p>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Data Types</h3>
      <p>
        JavaScript has eight basic data types:
      </p>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">1. Primitive Data Types</h4>
      
      <CodeBlock
        language="javascript"
        code={`// 1. String
let name = "John";
let greeting = 'Hello';
let template = `Hello, ${name}`; // Template literal with variable

// 2. Number
let age = 30;
let price = 19.99;
let infinity = Infinity;
let notANumber = NaN;

// 3. Boolean
let isActive = true;
let isLoggedIn = false;

// 4. Undefined
let undefinedVar;
console.log(undefinedVar); // undefined

// 5. Null
let emptyValue = null;

// 6. Symbol (unique identifiers)
let id = Symbol("id");

// 7. BigInt (for large integers)
let bigNumber = 9007199254740991n; // Add 'n' at the end
let anotherBigNumber = BigInt(9007199254740991);`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">2. Object Data Type</h4>
      
      <CodeBlock
        language="javascript"
        code={`// 8. Object
// Objects can store collections of data and more complex entities
let person = {
  firstName: "John",
  lastName: "Doe",
  age: 30
};

// Arrays (special type of object)
let colors = ["red", "green", "blue"];

// Functions (also objects in JavaScript)
function greet() {
  return "Hello!";
}`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Type Checking and Conversion</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Checking Types</h4>
      <CodeBlock
        language="javascript"
        code={`// Using typeof operator
console.log(typeof "Hello"); // "string"
console.log(typeof 42); // "number"
console.log(typeof true); // "boolean"
console.log(typeof undefined); // "undefined"
console.log(typeof {}); // "object"
console.log(typeof []); // "object" (arrays are objects)
console.log(typeof null); // "object" (this is a known quirk)
console.log(typeof function(){}); // "function"
console.log(typeof Symbol('id')); // "symbol"
console.log(typeof 42n); // "bigint"

// Better way to check for arrays
console.log(Array.isArray([])); // true
console.log(Array.isArray({})); // false`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Type Conversion</h4>
      <CodeBlock
        language="javascript"
        code={`// String conversion
let value = 42;
let strValue = String(value); // Explicit conversion
let strValue2 = value + ""; // Implicit conversion
console.log(typeof strValue); // "string"

// Number conversion
let str = "42";
let num = Number(str); // Explicit conversion
let num2 = +str; // Implicit conversion using unary plus
let num3 = parseInt(str, 10); // Parse integer (base 10)
let num4 = parseFloat("42.5"); // Parse float
console.log(typeof num); // "number"

// Boolean conversion
let truthyValue = Boolean(42); // true
let falsyValue = Boolean(0); // false
console.log(typeof truthyValue); // "boolean"

// Truthy and falsy values in JavaScript
// Falsy values: false, 0, "", null, undefined, NaN
// Everything else is truthy`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Template Literals</h3>
      <p>
        Template literals provide an easier way to create strings with embedded expressions:
      </p>
      
      <CodeBlock
        language="javascript"
        code={`let name = "John";
let age = 30;

// Old way (string concatenation)
let greeting1 = "Hello, my name is " + name + " and I am " + age + " years old.";

// Using template literals (backticks)
let greeting2 = `Hello, my name is ${name} and I am ${age} years old.`;

// Multi-line strings
let multiLine = `This is line 1
This is line 2
This is line 3`;

// Expressions in template literals
let a = 5;
let b = 10;
console.log(`Sum: ${a + b}, Product: ${a * b}`);`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Operators</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Arithmetic Operators</h4>
      <CodeBlock
        language="javascript"
        code={`let a = 10;
let b = 3;

console.log(a + b); // Addition: 13
console.log(a - b); // Subtraction: 7
console.log(a * b); // Multiplication: 30
console.log(a / b); // Division: 3.3333...
console.log(a % b); // Modulus (remainder): 1
console.log(a ** b); // Exponentiation: 1000

// Increment and decrement
let c = 5;
console.log(c++); // 5 (returns, then increments)
console.log(c); // 6
console.log(++c); // 7 (increments, then returns)

let d = 5;
console.log(d--); // 5 (returns, then decrements)
console.log(d); // 4
console.log(--d); // 3 (decrements, then returns)`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Comparison Operators</h4>
      <CodeBlock
        language="javascript"
        code={`let a = 5;
let b = "5";

console.log(a == b); // Equal (value): true
console.log(a === b); // Strict equal (value and type): false
console.log(a != b); // Not equal (value): false
console.log(a !== b); // Strict not equal (value and type): true
console.log(a > 3); // Greater than: true
console.log(a < 10); // Less than: true
console.log(a >= 5); // Greater than or equal to: true
console.log(a <= 4); // Less than or equal to: false`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Logical Operators</h4>
      <CodeBlock
        language="javascript"
        code={`let isActive = true;
let isAdmin = false;

console.log(isActive && isAdmin); // Logical AND: false
console.log(isActive || isAdmin); // Logical OR: true
console.log(!isActive); // Logical NOT: false

// Short-circuit evaluation
let user = null;
let userName = user && user.name; // If user is null, doesn't try to access name
console.log(userName); // null

let defaultName = user || { name: "Guest" };
console.log(defaultName); // { name: "Guest" }

// Nullish coalescing operator (??) - only for null/undefined
let value = null;
let result = value ?? "default";
console.log(result); // "default"

let zero = 0;
let result2 = zero ?? "default";
console.log(result2); // 0 (because 0 is not null or undefined)`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Assignment Operators</h4>
      <CodeBlock
        language="javascript"
        code={`let x = 10;

x += 5; // x = x + 5; (15)
x -= 3; // x = x - 3; (12)
x *= 2; // x = x * 2; (24)
x /= 4; // x = x / 4; (6)
x %= 4; // x = x % 4; (2)
x **= 3; // x = x ** 3; (8)

// Logical assignment operators (ES2021)
let y = null;
y ||= 10; // y = y || 10; (10)

let z = 5;
z &&= 2; // z = z && 2; (2)

let w = undefined;
w ??= 20; // w = w ?? 20; (20)`}
      />
      
      <div className="glass p-6 my-6">
        <h4 className="text-lg font-semibold mb-2">Data Type Best Practices</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>Use <code>===</code> and <code>!==</code> instead of <code>==</code> and <code>!=</code> to avoid unexpected type conversions</li>
          <li>Be explicit with type conversions to make your code more readable</li>
          <li>Use template literals for string interpolation instead of concatenation</li>
          <li>Be aware of JavaScript's type coercion rules when mixing types in operations</li>
          <li>Use descriptive variable names that indicate the type or purpose of the data</li>
        </ul>
      </div>
      
      <p>
        Understanding variables and data types is fundamental to JavaScript programming. In the next section, we'll explore how to use these variables in more complex structures and operations.
      </p>
    </>,
    
    // Functions and Scope
    <>
      <h2>Functions and Scope</h2>
      <p>
        Functions are one of the fundamental building blocks in JavaScript. They allow you to define reusable blocks of code, organize your program, and create abstractions.
      </p>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Function Declarations</h3>
      <p>
        There are several ways to define functions in JavaScript:
      </p>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Function Declaration</h4>
      <CodeBlock
        language="javascript"
        code={`// Function declaration (hoisted)
function greet(name) {
  return "Hello, " + name + "!";
}

// Calling a function
let greeting = greet("John");
console.log(greeting); // "Hello, John!"`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Function Expression</h4>
      <CodeBlock
        language="javascript"
        code={`// Function expression (not hoisted)
const greet = function(name) {
  return "Hello, " + name + "!";
};

console.log(greet("Jane")); // "Hello, Jane!"`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Arrow Functions</h4>
      <CodeBlock
        language="javascript"
        code={`// Arrow function (introduced in ES6)
const greet = (name) => {
  return "Hello, " + name + "!";
};

// Shorter syntax for single expression functions
const greet2 = name => "Hello, " + name + "!";

console.log(greet2("Alice")); // "Hello, Alice!"`}
      />
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">Function Declaration vs. Expression vs. Arrow</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li><strong>Function Declaration:</strong> Hoisted (can be called before declared), has <code>this</code> based on call site</li>
          <li><strong>Function Expression:</strong> Not hoisted, has <code>this</code> based on call site</li>
          <li><strong>Arrow Function:</strong> Not hoisted, no own <code>this</code> (inherits from parent scope), more concise syntax</li>
        </ul>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Function Parameters</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Default Parameters</h4>
      <CodeBlock
        language="javascript"
        code={`// Default parameters (ES6)
function greet(name = "Guest", greeting = "Hello") {
  return `${greeting}, ${name}!`;
}

console.log(greet()); // "Hello, Guest!"
console.log(greet("John")); // "Hello, John!"
console.log(greet("Jane", "Hi")); // "Hi, Jane!"`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Rest Parameters</h4>
      <CodeBlock
        language="javascript"
        code={`// Rest parameters (ES6)
function sum(...numbers) {
  return numbers.reduce((total, num) => total + num, 0);
}

console.log(sum(1, 2, 3, 4, 5)); // 15`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Arguments Object</h4>
      <CodeBlock
        language="javascript"
        code={`// The arguments object (older way, not available in arrow functions)
function logArguments() {
  console.log(arguments);
  for (let i = 0; i < arguments.length; i++) {
    console.log(arguments[i]);
  }
}

logArguments("a", "b", "c"); // Logs "a", "b", "c"`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Scope and Closures</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Variable Scope</h4>
      <CodeBlock
        language="javascript"
        code={`// Global scope
const globalVar = "I'm global";

function exampleFunction() {
  // Function scope
  const functionVar = "I'm function-scoped";
  
  if (true) {
    // Block scope (only for let and const)
    let blockVar = "I'm block-scoped";
    var functionScopedVar = "I'm function-scoped too";
    
    console.log(globalVar); // Accessible
    console.log(functionVar); // Accessible
    console.log(blockVar); // Accessible
  }
  
  console.log(globalVar); // Accessible
  console.log(functionVar); // Accessible
  console.log(functionScopedVar); // Accessible
  // console.log(blockVar); // Error: blockVar is not defined
}

exampleFunction();
console.log(globalVar); // Accessible
// console.log(functionVar); // Error: functionVar is not defined
// console.log(functionScopedVar); // Error: functionScopedVar is not defined
// console.log(blockVar); // Error: blockVar is not defined`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Closures</h4>
      <p>
        A closure is a function that has access to variables from its outer (enclosing) scope, even after the outer function has returned.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Closure example
function createCounter() {
  let count = 0; // This variable is "captured" by the inner function
  
  return function() {
    count++; // The inner function can access and modify count
    return count;
  };
}

const counter = createCounter();
console.log(counter()); // 1
console.log(counter()); // 2
console.log(counter()); // 3

// Another counter is independent
const counter2 = createCounter();
console.log(counter2()); // 1

// Practical example: private variables
function createPerson(name) {
  // name is private to this scope
  return {
    getName: function() {
      return name;
    },
    setName: function(newName) {
      name = newName;
    }
  };
}

const person = createPerson("John");
console.log(person.getName()); // "John"
person.setName("Jane");
console.log(person.getName()); // "Jane"`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Advanced Function Concepts</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Immediately Invoked Function Expressions (IIFE)</h4>
      <CodeBlock
        language="javascript"
        code={`// IIFE - Function that runs as soon as it's defined
(function() {
  const privateVar = "I'm private";
  console.log("IIFE executed!");
})();

// IIFE with parameters
(function(name) {
  console.log("Hello, " + name);
})("John");

// Modern alternative using blocks and let/const
{
  const privateVar = "I'm private";
  console.log("Block executed!");
}`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Higher-Order Functions</h4>
      <p>
        Higher-order functions are functions that take other functions as arguments or return functions.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Function as an argument
function doOperation(x, y, operation) {
  return operation(x, y);
}

const add = (a, b) => a + b;
const subtract = (a, b) => a - b;

console.log(doOperation(5, 3, add)); // 8
console.log(doOperation(5, 3, subtract)); // 2

// Function returning a function
function multiplyBy(factor) {
  return function(number) {
    return number * factor;
  };
}

const double = multiplyBy(2);
const triple = multiplyBy(3);

console.log(double(5)); // 10
console.log(triple(5)); // 15`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Recursion</h4>
      <p>
        Recursion is when a function calls itself.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Factorial function using recursion
function factorial(n) {
  // Base case
  if (n <= 1) {
    return 1;
  }
  // Recursive case
  return n * factorial(n - 1);
}

console.log(factorial(5)); // 120 (5 * 4 * 3 * 2 * 1)

// Fibonacci sequence using recursion
function fibonacci(n) {
  if (n <= 1) {
    return n;
  }
  return fibonacci(n - 1) + fibonacci(n - 2);
}

console.log(fibonacci(7)); // 13`}
      />
      
      <div className="glass p-6 my-6">
        <h4 className="text-lg font-semibold mb-2">The `this` Keyword</h4>
        <p className="mb-4 text-gray-700 dark:text-gray-300">
          The value of <code>this</code> depends on how a function is called:
        </p>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>In a method, <code>this</code> refers to the owner object</li>
          <li>Alone, <code>this</code> refers to the global object (window in browsers)</li>
          <li>In a function, <code>this</code> refers to the global object (strict mode: undefined)</li>
          <li>In an event, <code>this</code> refers to the element that received the event</li>
          <li>Methods like <code>call()</code>, <code>apply()</code>, and <code>bind()</code> can set <code>this</code> explicitly</li>
          <li>Arrow functions don't have their own <code>this</code>; they inherit from the parent scope</li>
        </ul>
      </div>
      
      <CodeBlock
        language="javascript"
        code={`
  ]
}// 'this' in different contexts
// Method
const person = {
  name: "John",
  greet: function() {
    console.log("Hello, I'm " + this.name);
  }
};
person.greet(); // "Hello, I'm John"

// Event handler
document.getElementById("myButton").addEventListener("click", function() {
  console.log(this); // Refers to the button element
});

// Arrow function
const person2 = {
  name: "Jane",
  greet: function() {
    // setTimeout with regular function
    setTimeout(function() {
      console.log("Hello, I'm " + this.name); // 'this' is window/global
    }, 100);
    
    // setTimeout with arrow function
    setTimeout(() => {
      console.log("Hello, I'm " + this.name); // 'this' is person2
    }, 200);
  }
};

// Setting 'this' explicitly
function introduce(greeting) {
  console.log(greeting + ", I'm " + this.name);
}

const john = { name: "John" };
const jane = { name: "Jane" };

introduce.call(john, "Hi"); // "Hi, I'm John"
introduce.apply(jane, ["Hello"]); // "Hello, I'm Jane"

const johnIntroduce = introduce.bind(john);
johnIntroduce("Hey"); // "Hey, I'm John"`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Function Best Practices</h3>
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">Best Practices</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>Write small, focused functions that do one thing well</li>
          <li>Use descriptive function names that indicate what the function does</li>
          <li>Keep functions pure when possible (same input always gives same output, no side effects)</li>
          <li>Use arrow functions for short callbacks and when you want to preserve the lexical <code>this</code></li>
          <li>Use default parameters for better function usability</li>
          <li>Understand closures to avoid unintended memory leaks</li>
          <li>Remember that functions are first-class citizens in JavaScript</li>
          <li>Document complex functions with comments explaining purpose and parameters</li>
        </ul>
      </div>
      
      <p>
        Functions are a powerful feature in JavaScript that enable code organization, reuse, and abstraction. Understanding functions and their nuances is essential for writing effective JavaScript code.
      </p>
    </>,
    
    // Arrays and Objects
    <>
      <h2>Arrays and Objects</h2>
      <p>
        Arrays and objects are the two main ways to store and organize collections of data in JavaScript. Understanding how to work with these data structures is essential for effective JavaScript programming.
      </p>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Arrays</h3>
      <p>
        Arrays are ordered collections of values that can be of any type. They use numeric indices starting at 0.
      </p>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Creating Arrays</h4>
      <CodeBlock
        language="javascript"
        code={`// Array literal notation
let fruits = ["apple", "banana", "orange"];

// Array constructor
let numbers = new Array(1, 2, 3, 4, 5);

// Empty array
let empty = [];

// Array with mixed types
let mixed = [42, "hello", true, null, { name: "John" }, [1, 2, 3]];

// Creating array with specific length
let zeros = new Array(5); // Creates array with 5 empty slots
console.log(zeros.length); // 5

// Array.from() - create arrays from array-like or iterable objects
let arrayFrom = Array.from("hello"); // ["h", "e", "l", "l", "o"]
let sequence = Array.from({ length: 5 }, (_, i) => i + 1); // [1, 2, 3, 4, 5]

// Array.of() - create array with values
let arrayOf = Array.of(1, 2, 3); // [1, 2, 3]`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Accessing and Modifying Arrays</h4>
      <CodeBlock
        language="javascript"
        code={`let fruits = ["apple", "banana", "orange", "grape", "mango"];

// Accessing elements by index
console.log(fruits[0]); // "apple"
console.log(fruits[2]); // "orange"

// Getting array length
console.log(fruits.length); // 5

// Modifying elements
fruits[1] = "pear";
console.log(fruits); // ["apple", "pear", "orange", "grape", "mango"]

// Adding elements to the end
fruits.push("kiwi");
console.log(fruits); // ["apple", "pear", "orange", "grape", "mango", "kiwi"]

// Removing elements from the end
let lastFruit = fruits.pop();
console.log(lastFruit); // "kiwi"
console.log(fruits); // ["apple", "pear", "orange", "grape", "mango"]

// Adding elements to the beginning
fruits.unshift("strawberry");
console.log(fruits); // ["strawberry", "apple", "pear", "orange", "grape", "mango"]

// Removing elements from the beginning
let firstFruit = fruits.shift();
console.log(firstFruit); // "strawberry"
console.log(fruits); // ["apple", "pear", "orange", "grape", "mango"]

// Finding element index
let orangeIndex = fruits.indexOf("orange");
console.log(orangeIndex); // 2

// Checking if element exists
let hasPear = fruits.includes("pear");
console.log(hasPear); // true

// Removing elements at specific position
let removed = fruits.splice(1, 2); // Remove 2 elements starting at index 1
console.log(removed); // ["pear", "orange"]
console.log(fruits); // ["apple", "grape", "mango"]

// Adding elements at specific position
fruits.splice(1, 0, "blueberry", "peach"); // Insert at index 1, remove 0 elements
console.log(fruits); // ["apple", "blueberry", "peach", "grape", "mango"]`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Array Methods</h4>
      <CodeBlock
        language="javascript"
        code={`let numbers = [1, 2, 3, 4, 5];
let fruits = ["apple", "banana", "orange", "grape"];

// forEach - execute a function on each element
numbers.forEach((num, index) => {
  console.log(`Element at index ${index} is ${num}`);
});

// map - create a new array by transforming each element
let doubled = numbers.map(num => num * 2);
console.log(doubled); // [2, 4, 6, 8, 10]

// filter - create a new array with elements that pass a test
let evenNumbers = numbers.filter(num => num % 2 === 0);
console.log(evenNumbers); // [2, 4]

// reduce - reduce array to a single value
let sum = numbers.reduce((total, num) => total + num, 0);
console.log(sum); // 15

// find - return the first element that passes a test
let firstEven = numbers.find(num => num % 2 === 0);
console.log(firstEven); // 2

// some - check if at least one element passes a test
let hasEven = numbers.some(num => num % 2 === 0);
console.log(hasEven); // true

// every - check if all elements pass a test
let allEven = numbers.every(num => num % 2 === 0);
console.log(allEven); // false

// sort - sort the elements (modifies original array)
let unsorted = [3, 1, 4, 1, 5, 9];
unsorted.sort();
console.log(unsorted); // [1, 1, 3, 4, 5, 9]

// sort with compare function
let numbers2 = [10, 5, 40, 25, 100];
numbers2.sort((a, b) => a - b); // Ascending order
console.log(numbers2); // [5, 10, 25, 40, 100]

// reverse - reverse the order of elements
fruits.reverse();
console.log(fruits); // ["grape", "orange", "banana", "apple"]

// join - join all elements into a string
let fruitString = fruits.join(", ");
console.log(fruitString); // "grape, orange, banana, apple"

// slice - return a portion of the array
let sliced = fruits.slice(1, 3);
console.log(sliced); // ["orange", "banana"]

// concat - combine arrays
let combined = numbers.concat(fruits);
console.log(combined); // [1, 2, 3, 4, 5, "grape", "orange", "banana", "apple"]

// flat - flatten nested arrays
let nested = [1, [2, 3], [4, [5, 6]]];
let flattened = nested.flat(2); // Depth of 2
console.log(flattened); // [1, 2, 3, 4, 5, 6]

// flatMap - map and then flatten
let sentences = ["hello world", "goodbye space"];
let words = sentences.flatMap(sentence => sentence.split(" "));
console.log(words); // ["hello", "world", "goodbye", "space"]`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Array Destructuring</h4>
      <CodeBlock
        language="javascript"
        code={`let colors = ["red", "green", "blue", "yellow", "purple"];

// Basic destructuring
let [first, second, third] = colors;
console.log(first, second, third); // "red", "green", "blue"

// Skip elements
let [primary, , tertiary] = colors;
console.log(primary, tertiary); // "red", "blue"

// Rest pattern
let [main, ...others] = colors;
console.log(main); // "red"
console.log(others); // ["green", "blue", "yellow", "purple"]

// Default values
let [head, tail = "default"] = ["only one"];
console.log(head, tail); // "only one", "default"

// Swapping variables
let a = 1, b = 2;
[a, b] = [b, a];
console.log(a, b); // 2, 1`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Objects</h3>
      <p>
        Objects are collections of key-value pairs where the keys are strings (or Symbols) and the values can be any data type.
      </p>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Creating Objects</h4>
      <CodeBlock
        language="javascript"
        code={`// Object literal notation
let person = {
  firstName: "John",
  lastName: "Doe",
  age: 30,
  isEmployed: true,
  skills: ["JavaScript", "HTML", "CSS"],
  address: {
    street: "123 Main St",
    city: "Anytown",
    country: "USA"
  }
};

// Empty object
let empty = {};

// Object constructor
let user = new Object();
user.name = "Jane";
user.age = 25;

// Object.create()
let prototype = { species: "human" };
let john = Object.create(prototype);
john.name = "John";
console.log(john.species); // "human" (inherited from prototype)`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Accessing and Modifying Objects</h4>
      <CodeBlock
        language="javascript"
        code={`let person = {
  firstName: "John",
  lastName: "Doe",
  age: 30
};

// Dot notation
console.log(person.firstName); // "John"
person.age = 31;
console.log(person.age); // 31

// Bracket notation
console.log(person["lastName"]); // "Doe"
person["eyeColor"] = "blue"; // Add new property
console.log(person["eyeColor"]); // "blue"

// Bracket notation is required for dynamic property names
let property = "firstName";
console.log(person[property]); // "John"

// Nested properties
let user = {
  name: "Alice",
  details: {
    height: 165,
    weight: 60
  }
};

console.log(user.details.height); // 165

// Deleting properties
delete person.eyeColor;
console.log(person.eyeColor); // undefined`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Object Methods</h4>
      <CodeBlock
        language="javascript"
        code={`let person = {
  firstName: "John",
  lastName: "Doe",
  // Method shorthand
  fullName() {
    return this.firstName + " " + this.lastName;
  },
  // Arrow function does not have its own 'this'
  getInfo: () => {
    // 'this' refers to the outer scope, not the person object
    return "Info";
  }
};

console.log(person.fullName()); // "John Doe"`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Object Methods and Properties</h4>
      <CodeBlock
        language="javascript"
        code={`let person = {
  name: "John",
  age: 30,
  city: "New York"
};

// Object.keys() - get all property names
console.log(Object.keys(person)); // ["name", "age", "city"]

// Object.values() - get all values
console.log(Object.values(person)); // ["John", 30, "New York"]

// Object.entries() - get [key, value] pairs
console.log(Object.entries(person)); // [["name", "John"], ["age", 30], ["city", "New York"]]

// Object.assign() - copy properties from one object to another
let details = { job: "Developer", country: "USA" };
let completePerson = Object.assign({}, person, details);
console.log(completePerson); // { name: "John", age: 30, city: "New York", job: "Developer", country: "USA" }

// Spread operator (alternative to Object.assign)
let completePersonSpread = { ...person, ...details };
console.log(completePersonSpread); // Same as completePerson

// Object.freeze() - prevent object from being modified
Object.freeze(person);
person.age = 31; // Will not change
console.log(person.age); // 30

// Object.seal() - prevent adding/removing properties, but allows modifying existing ones
let user = { name: "Jane", age: 25 };
Object.seal(user);
user.age = 26; // Allowed
user.job = "Developer"; // Not allowed
console.log(user); // { name: "Jane", age: 26 }

// Object.is() - check if two values are the same
console.log(Object.is(5, 5)); // true
console.log(Object.is(5, "5")); // false
console.log(Object.is(NaN, NaN)); // true (unlike ==)`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Object Destructuring</h4>
      <CodeBlock
        language="javascript"
        code={`let person = {
  firstName: "John",
  lastName: "Doe",
  age: 30,
  address: {
    street: "123 Main St",
    city: "Anytown",
    country: "USA"
  }
};

// Basic destructuring
let { firstName, lastName } = person;
console.log(firstName, lastName); // "John", "Doe"

// Assigning to different variable names
let { firstName: fName, lastName: lName } = person;
console.log(fName, lName); // "John", "Doe"

// Default values
let { age, job = "Unknown" } = person;
console.log(age, job); // 30, "Unknown"

// Nested destructuring
let { address: { city, country } } = person;
console.log(city, country); // "Anytown", "USA"

// Rest pattern
let { firstName: name, ...rest } = person;
console.log(name); // "John"
console.log(rest); // { lastName: "Doe", age: 30, address: {...} }

// Destructuring in function parameters
function printPersonInfo({ firstName, lastName, age }) {
  console.log(`${firstName} ${lastName}, ${age} years old`);
}

printPersonInfo(person); // "John Doe, 30 years old"`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">JSON</h3>
      <p>
        JSON (JavaScript Object Notation) is a text-based data format that's used for exchanging data between a server and a client.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// JavaScript object
let person = {
  name: "John",
  age: 30,
  isEmployed: true,
  skills: ["JavaScript", "HTML", "CSS"]
};

// Convert object to JSON string
let jsonString = JSON.stringify(person);
console.log(jsonString);
// {"name":"John","age":30,"isEmployed":true,"skills":["JavaScript","HTML","CSS"]}

// Pretty-print JSON
let prettyJson = JSON.stringify(person, null, 2);
console.log(prettyJson);
/*
{
  "name": "John",
  "age": 30,
  "isEmployed": true,
  "skills": [
    "JavaScript",
    "HTML",
    "CSS"
  ]
}
*/

// Convert JSON string back to object
let parsedPerson = JSON.parse(jsonString);
console.log(parsedPerson.name); // "John"

// JSON.stringify with replacer function
let personWithDates = {
  name: "John",
  birthDate: new Date(1990, 0, 1),
  registrationDate: new Date(2020, 0, 1)
};

let jsonWithDates = JSON.stringify(personWithDates, (key, value) => {
  if (value instanceof Date) {
    return value.toISOString();
  }
  return value;
});

console.log(jsonWithDates);
// {"name":"John","birthDate":"1990-01-01T00:00:00.000Z","registrationDate":"2020-01-01T00:00:00.000Z"}`}
      />
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">Arrays and Objects Best Practices</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>Use array methods like <code>map</code>, <code>filter</code>, and <code>reduce</code> instead of loops when appropriate</li>
          <li>Prefer object literals for creating objects with known properties</li>
          <li>Use destructuring to extract multiple properties from objects and arrays</li>
          <li>Use the spread operator for creating copies of arrays and objects</li>
          <li>Be careful when comparing objects and arrays (they are compared by reference, not value)</li>
          <li>Use <code>const</code> for objects and arrays when you don't need to reassign the variable</li>
          <li>Remember that <code>const</code> only prevents reassignment, not mutation of the object or array</li>
          <li>Use <code>Object.freeze()</code> if you need to prevent object mutation</li>
        </ul>
      </div>
      
      <p>
        Arrays and objects are fundamental data structures in JavaScript that you'll use in nearly every JavaScript program. Understanding how to work with them effectively is crucial for developing robust applications.
      </p>
    </>,
    
    // DOM Manipulation
    <>
      <h2>DOM Manipulation</h2>
      <p>
        The Document Object Model (DOM) is a programming interface for HTML and XML documents. It represents the page so that programs can change the document structure, style, and content. DOM manipulation is one of the most common tasks in JavaScript web development.
      </p>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Understanding the DOM</h3>
      <p>
        The DOM represents an HTML document as a tree of nodes. Each node represents a part of the document (element, attribute, text, etc.).
      </p>
      
      <div className="glass p-6 my-6">
        <h4 className="text-lg font-semibold mb-2">Key DOM Concepts</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li><strong>Document</strong>: The root of the DOM tree, representing the entire HTML document</li>
          <li><strong>Element</strong>: Represents an HTML element (e.g., <code>&lt;div&gt;</code>, <code>&lt;p&gt;</code>)</li>
          <li><strong>Attribute</strong>: Represents an attribute of an HTML element (e.g., <code>class</code>, <code>id</code>)</li>
          <li><strong>Text</strong>: Represents the text content of an element</li>
          <li><strong>Comment</strong>: Represents an HTML comment</li>
        </ul>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Selecting DOM Elements</h3>
      <p>
        JavaScript provides various methods to select elements from the DOM:
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// By ID (returns a single element)
const header = document.getElementById("header");

// By class name (returns a live HTMLCollection)
const paragraphs = document.getElementsByClassName("paragraph");

// By tag name (returns a live HTMLCollection)
const divs = document.getElementsByTagName("div");

// By CSS selector (returns the first matching element)
const firstButton = document.querySelector("button");

// By CSS selector (returns all matching elements as a static NodeList)
const allButtons = document.querySelectorAll("button.primary");

// By name attribute (returns a live NodeList)
const radioButtons = document.getElementsByName("gender");

// Selecting relative to another element
const container = document.querySelector(".container");
const childDivs = container.querySelectorAll("div");
const firstChild = container.firstElementChild;
const lastChild = container.lastElementChild;
const nextSibling = header.nextElementSibling;
const prevSibling = header.previousElementSibling;
const parent = header.parentElement;`}
      />
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">Live vs. Static Collections</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li><strong>Live Collections</strong> (HTMLCollection, some NodeList): Automatically update when the DOM changes</li>
          <li><strong>Static Collections</strong> (NodeList from querySelectorAll): Don't update when the DOM changes</li>
          <li>For consistency and modern practice, <code>querySelector</code> and <code>querySelectorAll</code> are generally preferred</li>
        </ul>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Manipulating DOM Elements</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Creating Elements</h4>
      <CodeBlock
        language="javascript"
        code={`// Create a new element
const newParagraph = document.createElement("p");

// Create a text node
const text = document.createTextNode("This is a new paragraph.");

// Create a comment
const comment = document.createComment("This is a comment");

// Create a document fragment (container for multiple elements)
const fragment = document.createDocumentFragment();`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Adding Elements to the DOM</h4>
      <CodeBlock
        language="javascript"
        code={`// Append a child to an element
const parent = document.querySelector(".container");
parent.appendChild(newParagraph);

// Insert before another element
const referenceElement = document.querySelector(".reference");
parent.insertBefore(newParagraph, referenceElement);

// Modern insertion methods
parent.append(newParagraph, text); // Can append multiple nodes
parent.prepend(newParagraph); // Insert at the beginning
referenceElement.before(newParagraph); // Insert before
referenceElement.after(newParagraph); // Insert after
referenceElement.replaceWith(newParagraph); // Replace

// Using insertAdjacentElement
element.insertAdjacentElement("beforebegin", newElement); // Before the element
element.insertAdjacentElement("afterbegin", newElement); // Inside the element, before first child
element.insertAdjacentElement("beforeend", newElement); // Inside the element, after last child
element.insertAdjacentElement("afterend", newElement); // After the element

// Using insertAdjacentHTML
element.insertAdjacentHTML("beforeend", "<p>New HTML content</p>");`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Removing Elements</h4>
      <CodeBlock
        language="javascript"
        code={`// Remove an element (older method)
const elementToRemove = document.querySelector(".to-remove");
elementToRemove.parentNode.removeChild(elementToRemove);

// Modern way to remove an element
elementToRemove.remove();

// Clear all children of an element
while (parent.firstChild) {
  parent.removeChild(parent.firstChild);
}

// Modern way to clear all children
parent.innerHTML = "";
// or
parent.textContent = "";`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Modifying Element Content</h4>
      <CodeBlock
        language="javascript"
        code={`const element = document.querySelector(".content");

// Get/set text content
console.log(element.textContent); // Get text content
element.textContent = "New text content"; // Set text content

// Get/set HTML content
console.log(element.innerHTML); // Get HTML content
element.innerHTML = "<strong>New</strong> HTML content"; // Set HTML content

// innerText vs. textContent
// textContent gets all text regardless of CSS visibility
// innerText respects CSS styling and doesn't return text of hidden elements
console.log(element.innerText);`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Working with Attributes</h3>
      <CodeBlock
        language="javascript"
        code={`const link = document.querySelector("a");

// Get, set, check, and remove attributes
console.log(link.getAttribute("href")); // Get attribute
link.setAttribute("href", "https://example.com"); // Set attribute
console.log(link.hasAttribute("target")); // Check if attribute exists
link.removeAttribute("target"); // Remove attribute

// Working with classes
link.className = "external-link"; // Set class (overwrites existing)
link.classList.add("highlighted"); // Add class
link.classList.remove("old-class"); // Remove class
link.classList.toggle("active"); // Toggle class (add if not present, remove if present)
console.log(link.classList.contains("external-link")); // Check if class exists

// Working with data attributes
console.log(link.dataset.id); // Get data-id attribute
link.dataset.status = "archived"; // Set data-status attribute`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Manipulating Styles</h3>
      <CodeBlock
        language="javascript"
        code={`const element = document.querySelector(".styled-element");

// Inline styles
element.style.color = "blue";
element.style.backgroundColor = "yellow"; // Use camelCase for hyphenated CSS properties
element.style.margin = "10px 20px";
element.style.fontWeight = "bold";

// Set multiple styles at once
Object.assign(element.style, {
  padding: "15px",
  border: "1px solid black",
  borderRadius: "5px"
});

// Get computed style (actual applied style after CSS)
const computedStyle = getComputedStyle(element);
console.log(computedStyle.fontSize);
console.log(computedStyle.getPropertyValue("color"));

// Add/remove inline style property
element.style.setProperty("font-size", "16px");
element.style.removeProperty("background-color");`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Traversing the DOM</h3>
      <CodeBlock
        language="javascript"
        code={`const parent = document.querySelector(".parent");

// Navigating between nodes
const firstChild = parent.firstChild; // First child (any node type)
const firstElement = parent.firstElementChild; // First element child
const lastChild = parent.lastChild; // Last child (any node type)
const lastElement = parent.lastElementChild; // Last element child
const nextSibling = parent.nextSibling; // Next sibling (any node type)
const nextElement = parent.nextElementSibling; // Next element sibling
const prevSibling = parent.previousSibling; // Previous sibling (any node type)
const prevElement = parent.previousElementSibling; // Previous element sibling
const parentNode = parent.parentNode; // Parent node
const parentElement = parent.parentElement; // Parent element

// Get all children
const childNodes = parent.childNodes; // All child nodes (including text nodes, comments)
const children = parent.children; // Only element children

// Check if element has children
console.log(parent.hasChildNodes()); // True if has any child nodes
console.log(parent.children.length > 0); // True if has element children`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Practical DOM Manipulation Example</h3>
      <p>
        Here's a complete example demonstrating various DOM manipulation techniques:
      </p>
      
      <CodeBlock
        language="html"
        code={`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DOM Manipulation Example</title>
  <style>
    .container {
      max-width: 600px;
      margin: 0 auto;
      font-family: Arial, sans-serif;
    }
    .todo-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px;
      margin: 5px 0;
      background-color: #f4f4f4;
      border-radius: 4px;
    }
    .completed {
      text-decoration: line-through;
      opacity: 0.7;
    }
    .todo-text {
      flex-grow: 1;
      margin: 0 10px;
    }
    button {
      padding: 5px 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .delete-btn {
      background-color: #ff4d4d;
      color: white;
    }
    .form-group {
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Todo List</h1>
    
    <div class="form-group">
      <input type="text" id="todoInput" placeholder="Add new todo">
      <button id="addBtn">Add</button>
    </div>
    
    <div id="todoList">
      <!-- Todo items will be added here -->
    </div>
  </div>

  <script>
    // DOM elements
    const todoInput = document.getElementById('todoInput');
    const addBtn = document.getElementById('addBtn');
    const todoList = document.getElementById('todoList');
    
    // Event listener for adding a todo
    addBtn.addEventListener('click', addTodo);
    
    // Add todo when Enter key is pressed
    todoInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        addTodo();
      }
    });
    
    // Add a new todo
    function addTodo() {
      const todoText = todoInput.value.trim();
      
      if (todoText !== '') {
        // Create todo item
        createTodoElement(todoText);
        
        // Clear input
        todoInput.value = '';
        todoInput.focus();
      }
    }
    
    // Create a new todo element
    function createTodoElement(text) {
      // Create the todo item container
      const todoItem = document.createElement('div');
      todoItem.className = 'todo-item';
      
      // Create checkbox
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.addEventListener('change', function() {
        todoText.classList.toggle('completed');
      });
      
      // Create todo text
      const todoText = document.createElement('span');
      todoText.className = 'todo-text';
      todoText.textContent = text;
      
      // Create delete button
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'delete-btn';
      deleteBtn.textContent = 'Delete';
      deleteBtn.addEventListener('click', function() {
        todoItem.remove();
      });
      
      // Append elements to todo item
      todoItem.appendChild(checkbox);
      todoItem.appendChild(todoText);
      todoItem.appendChild(deleteBtn);
      
      // Append todo item to list
      todoList.appendChild(todoItem);
    }
    
    // Add some initial todos
    function addInitialTodos() {
      const initialTodos = [
        'Learn HTML',
        'Learn CSS',
        'Learn JavaScript'
      ];
      
      initialTodos.forEach(todo => createTodoElement(todo));
    }
    
    // Initialize
    addInitialTodos();
  </script>
</body>
</html>`}
      />
      
      <div className="glass p-6 my-6">
        <h4 className="text-lg font-semibold mb-2">DOM Manipulation Best Practices</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>Minimize DOM manipulation; it's expensive in terms of performance</li>
          <li>Use document fragments for batch insertions</li>
          <li>Avoid frequent reflows and repaints by grouping DOM changes</li>
          <li>Prefer modern DOM methods (e.g., <code>append</code>, <code>remove</code>)</li>
          <li>Cache DOM references when accessing elements multiple times</li>
          <li>Use event delegation for handling events on multiple similar elements</li>
          <li>For complex UI updates, consider using a library/framework (React, Vue, etc.)</li>
          <li>Be careful with <code>innerHTML</code> to avoid XSS vulnerabilities</li>
        </ul>
      </div>
      
      <p>
        DOM manipulation is a core skill for frontend JavaScript development. While modern frameworks often abstract direct DOM manipulation, understanding these fundamentals is crucial for writing efficient JavaScript code and debugging issues in your web applications.
      </p>
    </>,
    
    // Events and Event Handling
    <>
      <h2>Events and Event Handling</h2>
      <p>
        Events are actions or occurrences that happen in the browser, such as user interactions or browser status changes. Event handling is the process of writing code that responds to these events.
      </p>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Understanding Events</h3>
      <p>
        JavaScript uses an event-driven programming model, where code execution is triggered by events rather than following a predetermined sequence.
      </p>
      
      <div className="glass p-6 my-6">
        <h4 className="text-lg font-semibold mb-2">Common Event Types</h4>
        <ul className="list-disc list-inside grid grid-cols-1 md:grid-cols-2 gap-2 text-gray-700 dark:text-gray-300">
          <li><strong>Mouse events</strong>: click, dblclick, mousedown, mouseup, mousemove, mouseover, mouseout, mouseenter, mouseleave</li>
          <li><strong>Keyboard events</strong>: keydown, keyup, keypress</li>
          <li><strong>Form events</strong>: submit, reset, change, input, focus, blur</li>
          <li><strong>Window events</strong>: load, resize, scroll, unload, beforeunload</li>
          <li><strong>Document events</strong>: DOMContentLoaded</li>
          <li><strong>CSS events</strong>: transitionend, animationend</li>
          <li><strong>Touch events</strong>: touchstart, touchend, touchmove, touchcancel</li>
          <li><strong>Drag events</strong>: dragstart, drag, dragenter, dragleave, dragover, drop, dragend</li>
        </ul>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Event Handling Methods</h3>
      <p>
        There are several ways to handle events in JavaScript:
      </p>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">1. HTML Attribute (Inline)</h4>
      <CodeBlock
        language="html"
        code={`<button onclick="alert('Button clicked!')">Click Me</button>

<a href="https://example.com" onclick="event.preventDefault(); console.log('Link clicked!')">
  Example Link
</a>`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">2. DOM Property</h4>
      <CodeBlock
        language="javascript"
        code={`const button = document.querySelector('#myButton');

button.onclick = function() {
  console.log('Button clicked!');
};

// Only one handler can be attached this way
// This will overwrite the previous handler
button.onclick = function() {
  console.log('New handler');
};`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">3. addEventListener Method (Recommended)</h4>
      <CodeBlock
        language="javascript"
        code={`const button = document.querySelector('#myButton');

// Add event listener (multiple can be added)
button.addEventListener('click', function() {
  console.log('First handler');
});

button.addEventListener('click', function() {
  console.log('Second handler');
});

// With a named function
function handleClick() {
  console.log('Button clicked!');
}

button.addEventListener('click', handleClick);

// Remove event listener (must use the same function reference)
button.removeEventListener('click', handleClick);`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">The Event Object</h3>
      <p>
        When an event occurs, the browser creates an event object with information about the event. This object is automatically passed to event handlers.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`const button = document.querySelector('#myButton');

button.addEventListener('click', function(event) {
  // The event object
  console.log(event);
  
  // Common event properties
  console.log(event.type); // "click"
  console.log(event.target); // The element that triggered the event
  console.log(event.currentTarget); // The element the listener is attached to
  console.log(event.timeStamp); // Time when the event was created
  
  // Coordinates (for mouse events)
  console.log(event.clientX, event.clientY); // Relative to viewport
  console.log(event.pageX, event.pageY); // Relative to document
  console.log(event.screenX, event.screenY); // Relative to screen
  
  // Methods
  event.preventDefault(); // Prevent default behavior
  event.stopPropagation(); // Stop event bubbling
});

// Keyboard event example
document.addEventListener('keydown', function(event) {
  console.log(event.key); // The key that was pressed
  console.log(event.code); // Physical key code
  console.log(event.keyCode); // Deprecated, but still used
  console.log(event.altKey); // Whether Alt key was pressed
  console.log(event.ctrlKey); // Whether Ctrl key was pressed
  console.log(event.shiftKey); // Whether Shift key was pressed
});`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Event Propagation</h3>
      <p>
        When an event occurs on an element, it first runs the handlers on it, then on its parent, then all the way up on other ancestors. This process is called event bubbling.
      </p>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Event Bubbling and Capturing</h4>
      <CodeBlock
        language="javascript"
        code={`/*
HTML structure:
<div id="outer">
  <div id="inner">
    <button id="button">Click Me</button>
  </div>
</div>
*/

const outer = document.querySelector('#outer');
const inner = document.querySelector('#inner');
const button = document.querySelector('#button');

// Event bubbling (default) - events bubble up from target to ancestors
button.addEventListener('click', function(event) {
  console.log('Button clicked (bubbling)');
});

inner.addEventListener('click', function(event) {
  console.log('Inner div clicked (bubbling)');
});

outer.addEventListener('click', function(event) {
  console.log('Outer div clicked (bubbling)');
});

// Event capturing - events travel from ancestors down to target
// Third parameter 'true' enables capturing phase
button.addEventListener('click', function(event) {
  console.log('Button clicked (capturing)');
}, true);

inner.addEventListener('click', function(event) {
  console.log('Inner div clicked (capturing)');
}, true);

outer.addEventListener('click', function(event) {
  console.log('Outer div clicked (capturing)');
}, true);

// When button is clicked, the execution order will be:
// 1. Outer div clicked (capturing)
// 2. Inner div clicked (capturing)
// 3. Button clicked (capturing)
// 4. Button clicked (bubbling)
// 5. Inner div clicked (bubbling)
// 6. Outer div clicked (bubbling)`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Stopping Propagation</h4>
      <CodeBlock
        language="javascript"
        code={`button.addEventListener('click', function(event) {
  console.log('Button clicked');
  
  // Stop the event from bubbling up to parent elements
  event.stopPropagation();
});

// This handler won't be called if the button is clicked
inner.addEventListener('click', function(event) {
  console.log('Inner div clicked'); // This won't run when button is clicked
});`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Event Delegation</h3>
      <p>
        Event delegation is a technique where you attach a single event listener to a common ancestor of multiple elements, rather than adding event listeners to each individual element.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`/*
HTML structure:
<ul id="todo-list">
  <li>Item 1 <button class="delete">Delete</button></li>
  <li>Item 2 <button class="delete">Delete</button></li>
  <li>Item 3 <button class="delete">Delete</button></li>
</ul>
*/

// Without event delegation (not ideal)
const deleteButtons = document.querySelectorAll('.delete');
deleteButtons.forEach(button => {
  button.addEventListener('click', function() {
    this.parentElement.remove();
  });
});

// With event delegation (better)
const todoList = document.querySelector('#todo-list');

todoList.addEventListener('click', function(event) {
  // Check if the clicked element is a delete button
  if (event.target.classList.contains('delete')) {
    // Remove the parent li element
    event.target.parentElement.remove();
  }
});

// Benefits of event delegation:
// 1. Works for dynamically added elements
// 2. Less memory usage (only one event listener)
// 3. No need to rebind events when DOM changes`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Common Events and Examples</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Form Events</h4>
      <CodeBlock
        language="javascript"
        code={`// Form submission
const form = document.querySelector('#myForm');

form.addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission
  
  // Get form data
  const formData = new FormData(this);
  for (const [name, value] of formData.entries()) {
    console.log(`${name}: ${value}`);
  }
  
  // Or access form elements directly
  const username = this.elements.username.value;
  const password = this.elements.password.value;
  
  console.log(username, password);
});

// Input events
const input = document.querySelector('#username');

input.addEventListener('input', function(event) {
  console.log('Input value changed:', this.value);
});

input.addEventListener('focus', function() {
  this.classList.add('focused');
});

input.addEventListener('blur', function() {
  this.classList.remove('focused');
  
  // Validate on blur
  if (this.value.length < 3) {
    this.classList.add('error');
  } else {
    this.classList.remove('error');
  }
});

// Select/dropdown change
const select = document.querySelector('#country');

select.addEventListener('change', function() {
  console.log('Selected country:', this.value);
});`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Mouse Events</h4>
      <CodeBlock
        language="javascript"
        code={`const element = document.querySelector('#interactive');

// Click events
element.addEventListener('click', function(event) {
  console.log('Clicked at:', event.clientX, event.clientY);
});

element.addEventListener('dblclick', function() {
  console.log('Double clicked!');
});

// Mouse movement
element.addEventListener('mousemove', function(event) {
  // Throttle to improve performance (not calling on every pixel movement)
  if (this.throttleTimeout) clearTimeout(this.throttleTimeout);
  
  this.throttleTimeout = setTimeout(() => {
    console.log('Mouse position:', event.clientX, event.clientY);
  }, 100);
});

// Mouse enter/leave (doesn't bubble)
element.addEventListener('mouseenter', function() {
  this.classList.add('hovered');
});

element.addEventListener('mouseleave', function() {
  this.classList.remove('hovered');
});

// Right-click (context menu)
element.addEventListener('contextmenu', function(event) {
  event.preventDefault(); // Prevent the default context menu
  console.log('Right-clicked!');
  // Show custom context menu
});`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Keyboard Events</h4>
      <CodeBlock
        language="javascript"
        code={`// Listen for keyboard events
document.addEventListener('keydown', function(event) {
  console.log('Key down:', event.key);
  
  // Check for specific keys
  if (event.key === 'Escape') {
    console.log('Escape key pressed');
  }
  
  // Check for key combinations
  if (event.ctrlKey && event.key === 's') {
    event.preventDefault(); // Prevent browser's save dialog
    console.log('Ctrl+S pressed');
    // Perform save action
  }
});

document.addEventListener('keyup', function(event) {
  console.log('Key released:', event.key);
});

// Input-specific keyboard handling
const searchInput = document.querySelector('#search');

searchInput.addEventListener('keyup', function(event) {
  if (event.key === 'Enter') {
    console.log('Searching for:', this.value);
    // Perform search
  }
});`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Window and Document Events</h4>
      <CodeBlock
        language="javascript"
        code={`// Page load events
window.addEventListener('load', function() {
  console.log('Page fully loaded (including images and styles)');
});

document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM fully loaded (but may still be waiting for images and stylesheets)');
  // Safer to initialize your JS here instead of waiting for window.load
});

// Resize event
window.addEventListener('resize', function() {
  // Throttle to improve performance
  if (this.resizeTimeout) clearTimeout(this.resizeTimeout);
  
  this.resizeTimeout = setTimeout(() => {
    console.log('Window resized to:', window.innerWidth, window.innerHeight);
    
    // Check for mobile/desktop breakpoint
    if (window.innerWidth < 768) {
      document.body.classList.add('mobile');
    } else {
      document.body.classList.remove('mobile');
    }
  }, 200);
});

// Scroll event
window.addEventListener('scroll', function() {
  // Throttle to improve performance
  if (this.scrollTimeout) clearTimeout(this.scrollTimeout);
  
  this.scrollTimeout = setTimeout(() => {
    console.log('Scrolled to:', window.scrollX, window.scrollY);
    
    // Show/hide back-to-top button
    const backToTopBtn = document.querySelector('#backToTop');
    if (window.scrollY > 300) {
      backToTopBtn.classList.add('visible');
    } else {
      backToTopBtn.classList.remove('visible');
    }
  }, 100);
});

// Before unload (confirm navigation away)
window.addEventListener('beforeunload', function(event) {
  // Check if there are unsaved changes
  if (hasUnsavedChanges) {
    event.preventDefault();
    // Modern browsers ignore this message and show their own
    event.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
    return event.returnValue;
  }
});`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Practical Event Handling Example</h3>
      <p>
        Here's a complete example demonstrating various event handling techniques:
      </p>
      
      <CodeBlock
        language="html"
        code={`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Event Handling Example</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .container {
      display: flex;
      gap: 20px;
    }
    
    .sidebar {
      width: 200px;
      background-color: #f4f4f4;
      padding: 10px;
      border-radius: 4px;
    }
    
    .content {
      flex: 1;
    }
    
    .tab {
      padding: 10px;
      cursor: pointer;
      margin-bottom: 5px;
      background-color: #e0e0e0;
      border-radius: 4px;
      transition: background-color 0.3s;
    }
    
    .tab:hover {
      background-color: #d0d0d0;
    }
    
    .tab.active {
      background-color: #4CAF50;
      color: white;
    }
    
    .tab-content {
      display: none;
      padding: 20px;
      background-color: #f9f9f9;
      border-radius: 4px;
    }
    
    .tab-content.active {
      display: block;
    }
    
    #colorPicker {
      display: flex;
      gap: 10px;
      margin-top: 20px;
    }
    
    .color-box {
      width: 30px;
      height: 30px;
      border-radius: 4px;
      cursor: pointer;
      transition: transform 0.2s;
    }
    
    .color-box:hover {
      transform: scale(1.1);
    }
    
    form {
      margin-top: 20px;
    }
    
    input, textarea, button {
      display: block;
      width: 100%;
      margin-bottom: 10px;
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
    }
    
    button {
      background-color: #4CAF50;
      color: white;
      border: none;
      cursor: pointer;
    }
    
    button:hover {
      background-color: #45a049;
    }
    
    .error {
      border-color: red;
    }
    
    .validation-message {
      color: red;
      font-size: 12px;
      margin-top: -8px;
      margin-bottom: 10px;
      display: none;
    }
    
    #backToTop {
      position: fixed;
      bottom: 20px;
      right: 20px;
      padding: 10px;
      background-color: #333;
      color: white;
      border-radius: 4px;
      cursor: pointer;
      display: none;
    }
    
    #backToTop.visible {
      display: block;
    }
  </style>
</head>
<body>
  <h1>Event Handling Demo</h1>
  
  <div class="container">
    <div class="sidebar">
      <div id="tabs">
        <div class="tab active" data-tab="tab1">Tab 1</div>
        <div class="tab" data-tab="tab2">Tab 2</div>
        <div class="tab" data-tab="tab3">Tab 3</div>
      </div>
      
      <div id="colorPicker">
        <div class="color-box" style="background-color: #3498db;" data-color="#3498db"></div>
        <div class="color-box" style="background-color: #e74c3c;" data-color="#e74c3c"></div>
        <div class="color-box" style="background-color: #2ecc71;" data-color="#2ecc71"></div>
        <div class="color-box" style="background-color: #f39c12;" data-color="#f39c12"></div>
      </div>
    </div>
    
    <div class="content">
      <div id="tab1" class="tab-content active">
        <h2>Form Events</h2>
        <form id="contactForm">
          <input type="text" id="name" name="name" placeholder="Your Name" required>
          <span class="validation-message" id="nameError">Please enter your name</span>
          
          <input type="email" id="email" name="email" placeholder="Your Email" required>
          <span class="validation-message" id="emailError">Please enter a valid email</span>
          
          <textarea id="message" name="message" placeholder="Your Message" rows="4" required></textarea>
          <span class="validation-message" id="messageError">Please enter a message</span>
          
          <button type="submit">Submit</button>
        </form>
      </div>
      
      <div id="tab2" class="tab-content">
        <h2>Mouse Events</h2>
        <div id="mouseTracker" style="width: 100%; height: 200px; background-color: #f0f0f0; position: relative; overflow: hidden;">
          <div style="padding: 10px;">Move your mouse inside this area</div>
          <div id="follower" style="position: absolute; width: 20px; height: 20px; background-color: red; border-radius: 50%; pointer-events: none; transform: translate(-50%, -50%);"></div>
        </div>
      </div>
      
      <div id="tab3" class="tab-content">
        <h2>Keyboard Events</h2>
        <p>Press any key to see its code. Try Ctrl, Alt, Shift combinations too.</p>
        <input type="text" id="keyboardInput" placeholder="Type here...">
        <div id="keyInfo" style="margin-top: 20px; padding: 15px; background-color: #e0e0e0; border-radius: 4px;">
          Press any key to see information
        </div>
      </div>
    </div>
  </div>
  
  <div id="backToTop">↑ Top</div>
  
  <script>
    // DOM Elements
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const colorBoxes = document.querySelectorAll('.color-box');
    const contactForm = document.getElementById('contactForm');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');
    const mouseTracker = document.getElementById('mouseTracker');
    const follower = document.getElementById('follower');
    const keyboardInput = document.getElementById('keyboardInput');
    const keyInfo = document.getElementById('keyInfo');
    const backToTopBtn = document.getElementById('backToTop');
    
    // Tab Switching with Event Delegation
    document.getElementById('tabs').addEventListener('click', function(event) {
      // Check if a tab was clicked
      if (event.target.classList.contains('tab')) {
        // Remove active class from all tabs and contents
        tabs.forEach(tab => tab.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        // Add active class to clicked tab
        event.target.classList.add('active');
        
        // Show corresponding content
        const tabId = event.target.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
      }
    });
    
    // Color Picker with Event Delegation
    document.getElementById('colorPicker').addEventListener('click', function(event) {
      if (event.target.classList.contains('color-box')) {
        const color = event.target.getAttribute('data-color');
        document.body.style.backgroundColor = color;
      }
    });
    
    // Form Validation
    contactForm.addEventListener('submit', function(event) {
      event.preventDefault();
      
      let isValid = true;
      
      // Reset validation messages
      document.querySelectorAll('.validation-message').forEach(msg => {
        msg.style.display = 'none';
      });
      
      // Validate name
      if (nameInput.value.trim() === '') {
        document.getElementById('nameError').style.display = 'block';
        nameInput.classList.add('error');
        isValid = false;
      } else {
        nameInput.classList.remove('error');
      }
      
      // Validate email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailInput.value)) {
        document.getElementById('emailError').style.display = 'block';
        emailInput.classList.add('error');
        isValid = false;
      } else {
        emailInput.classList.remove('error');
      }
      
      // Validate message
      if (messageInput.value.trim() === '') {
        document.getElementById('messageError').style.display = 'block';
        messageInput.classList.add('error');
        isValid = false;
      } else {
        messageInput.classList.remove('error');
      }
      
      // If form is valid, submit it (or show success message)
      if (isValid) {
        alert('Form submitted successfully!');
        this.reset();
      }
    });
    
    // Real-time input validation
    const inputs = [nameInput, emailInput, messageInput];
    
    inputs.forEach(input => {
      input.addEventListener('input', function() {
        if (this.value.trim() !== '') {
          this.classList.remove('error');
          const errorId = this.id + 'Error';
          document.getElementById(errorId).style.display = 'none';
        }
      });
    });
    
    // Mouse follower
    mouseTracker.addEventListener('mousemove', function(event) {
      // Get position relative to the container
      const rect = this.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      
      // Position the follower
      follower.style.left = x + 'px';
      follower.style.top = y + 'px';
    });
    
    // Mouse enter/leave
    mouseTracker.addEventListener('mouseenter', function() {
      follower.style.display = 'block';
    });
    
    mouseTracker.addEventListener('mouseleave', function() {
      follower.style.display = 'none';
    });
    
    // Keyboard events
    keyboardInput.addEventListener('keydown', function(event) {
      // Prevent default for certain key combinations
      if (event.ctrlKey && event.key === 's') {
        event.preventDefault();
      }
      
      // Display key information
      keyInfo.innerHTML = `
        <strong>Key:</strong> ${event.key}<br>
        <strong>Code:</strong> ${event.code}<br>
        <strong>Alt:</strong> ${event.altKey}<br>
        <strong>Ctrl:</strong> ${event.ctrlKey}<br>
        <strong>Shift:</strong> ${event.shiftKey}
      `;
    });
    
    // Scroll event for back to top button
    window.addEventListener('scroll', function() {
      if (window.pageYOffset > 300) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    });
    
    // Back to top button click
    backToTopBtn.addEventListener('click', function() {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
    
    // Add some content to make the page scrollable
    const content = document.querySelector('.content');
    for (let i = 0; i < 10; i++) {
      const p = document.createElement('p');
      p.textContent = 'This is some extra content to make the page scrollable. Scroll down to see the back to top button appear.';
      content.appendChild(p);
    }
  </script>
</body>
</html>`}
      />
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">Event Handling Best Practices</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>Use <code>addEventListener</code> over inline attributes or DOM properties</li>
          <li>Use event delegation for handling events on multiple similar elements</li>
          <li>Throttle or debounce high-frequency events (scroll, resize, mousemove)</li>
          <li>Keep event handlers small and focused, delegate complex logic to separate functions</li>
          <li>Always consider accessibility (keyboard events alongside mouse events)</li>
          <li>Be cautious with <code>preventDefault()</code> to not break expected user interactions</li>
          <li>Properly remove event listeners when components are destroyed to prevent memory leaks</li>
          <li>Remember that <code>this</code> in an event handler refers to the element the event is attached to (unless using arrow functions)</li>
        </ul>
      </div>
      
      <p>
        Event handling is a fundamental aspect of JavaScript programming for the web. By mastering these concepts, you can create interactive, responsive web applications that provide a great user experience.
      </p>
    </>,
    
    // Asynchronous JavaScript
    <>
      <h2>Asynchronous JavaScript</h2>
      <p>
        Asynchronous programming allows operations to run in the background while the rest of the code continues to execute. This is essential for tasks like fetching data from servers, handling user input, or setting timers, all without blocking the main thread.
      </p>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Understanding Synchronous vs. Asynchronous</h3>
      <div className="glass p-6 my-6">
        <h4 className="text-lg font-semibold mb-2">Key Differences</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li><strong>Synchronous</strong>: Operations execute one after another, blocking the execution until each operation completes</li>
          <li><strong>Asynchronous</strong>: Operations can run in parallel, allowing the program to continue executing while waiting for certain operations to complete</li>
        </ul>
      </div>
      
      <CodeBlock
        language="javascript"
        code={`// Synchronous code
console.log("First");
console.log("Second");
console.log("Third");
// Output: First, Second, Third (in order)

// Asynchronous code example
console.log("First");
setTimeout(() => {
  console.log("Second (after delay)");
}, 1000);
console.log("Third");
// Output: First, Third, Second (after delay)`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">The Call Stack and Event Loop</h3>
      <p>
        To understand asynchronous JavaScript, it's important to know how JavaScript handles execution behind the scenes.
      </p>
      
      <div className="glass p-6 my-6">
        <h4 className="text-lg font-semibold mb-2">JavaScript Runtime Components</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li><strong>Call Stack</strong>: Tracks function calls, following a Last In, First Out (LIFO) principle</li>
          <li><strong>Web APIs</strong>: Browser-provided APIs like setTimeout, fetch, DOM events</li>
          <li><strong>Callback Queue</strong>: Holds callbacks from asynchronous operations waiting to be executed</li>
          <li><strong>Event Loop</strong>: Checks if the call stack is empty, then moves callbacks from the queue to the stack</li>
        </ul>
      </div>
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Callbacks</h3>
      <p>
        Callbacks are functions passed as arguments to other functions, to be executed after a certain event or operation completes.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Simple callback example
function greet(name, callback) {
  console.log("Hello, " + name);
  callback();
}

greet("John", function() {
  console.log("Callback executed!");
});

// Real-world example: setTimeout
setTimeout(function() {
  console.log("Timeout completed!");
}, 2000);

// Event listeners use callbacks
document.getElementById("myButton").addEventListener("click", function() {
  console.log("Button clicked!");
});

// AJAX with callbacks (older approach)
function fetchData(url, successCallback, errorCallback) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", url);
  
  xhr.onload = function() {
    if (xhr.status === 200) {
      successCallback(xhr.responseText);
    } else {
      errorCallback("Request failed with status: " + xhr.status);
    }
  };
  
  xhr.onerror = function() {
    errorCallback("Network error occurred");
  };
  
  xhr.send();
}

fetchData(
  "https://api.example.com/data",
  function(data) {
    console.log("Success:", data);
  },
  function(error) {
    console.error("Error:", error);
  }
);`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Callback Hell</h4>
      <p>
        When multiple asynchronous operations depend on each other, callbacks can lead to deeply nested code, often called "callback hell" or "pyramid of doom."
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Callback hell example
fetchData("https://api.example.com/users", function(users) {
  console.log("Users loaded");
  fetchData("https://api.example.com/posts", function(posts) {
    console.log("Posts loaded");
    fetchData("https://api.example.com/comments", function(comments) {
      console.log("Comments loaded");
      fetchData("https://api.example.com/likes", function(likes) {
        console.log("Likes loaded");
        // Combine data and update UI
        updateUI(users, posts, comments, likes);
      }, function(error) {
        console.error("Error loading likes:", error);
      });
    }, function(error) {
      console.error("Error loading comments:", error);
    });
  }, function(error) {
    console.error("Error loading posts:", error);
  });
}, function(error) {
  console.error("Error loading users:", error);
});`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Promises</h3>
      <p>
        Promises are objects representing the eventual completion or failure of an asynchronous operation. They provide a cleaner way to handle asynchronous code.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Creating a promise
const myPromise = new Promise((resolve, reject) => {
  // Asynchronous operation
  const success = true;
  
  if (success) {
    resolve("Operation completed successfully!");
  } else {
    reject("Operation failed!");
  }
});

// Using a promise
myPromise
  .then(result => {
    console.log("Success:", result);
  })
  .catch(error => {
    console.error("Error:", error);
  })
  .finally(() => {
    console.log("Promise completed (regardless of success or failure)");
  });

// Promise with setTimeout
function delay(ms) {
  return new Promise(resolve => {
    setTimeout(resolve, ms);
  });
}

delay(2000)
  .then(() => {
    console.log("Delayed for 2 seconds");
  });

// Converting callback-based API to promise
function fetchDataPromise(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url);
    
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.responseText);
      } else {
        reject("Request failed with status: " + xhr.status);
      }
    };
    
    xhr.onerror = function() {
      reject("Network error occurred");
    };
    
    xhr.send();
  });
}

fetchDataPromise("https://api.example.com/data")
  .then(data => {
    console.log("Success:", data);
  })
  .catch(error => {
    console.error("Error:", error);
  });`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Promise Chaining</h4>
      <p>
        Promises can be chained to handle sequential asynchronous operations, avoiding callback hell.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Promise chaining example
fetchDataPromise("https://api.example.com/users")
  .then(users => {
    console.log("Users loaded");
    return fetchDataPromise("https://api.example.com/posts");
  })
  .then(posts => {
    console.log("Posts loaded");
    return fetchDataPromise("https://api.example.com/comments");
  })
  .then(comments => {
    console.log("Comments loaded");
    return fetchDataPromise("https://api.example.com/likes");
  })
  .then(likes => {
    console.log("Likes loaded");
    // Process all data here
  })
  .catch(error => {
    console.error("Error in the chain:", error);
  });

// Returning values in promise chains
fetch("https://api.example.com/users/1")
  .then(response => response.json())
  .then(user => {
    console.log("User:", user);
    return fetch("https://api.example.com/posts?userId=" + user.id);
  })
  .then(response => response.json())
  .then(posts => {
    console.log("User's posts:", posts);
  })
  .catch(error => {
    console.error("Error:", error);
  });`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Promise Methods</h4>
      <CodeBlock
        language="javascript"
        code={`// Promise.all - waits for all promises to resolve
const promise1 = fetch("https://api.example.com/users").then(res => res.json());
const promise2 = fetch("https://api.example.com/posts").then(res => res.json());
const promise3 = fetch("https://api.example.com/comments").then(res => res.json());

Promise.all([promise1, promise2, promise3])
  .then(([users, posts, comments]) => {
    console.log("All data loaded", users, posts, comments);
  })
  .catch(error => {
    console.error("At least one request failed:", error);
  });

// Promise.race - resolves or rejects as soon as one promise resolves/rejects
const fastPromise = new Promise(resolve => setTimeout(() => resolve("Fast!"), 100));
const slowPromise = new Promise(resolve => setTimeout(() => resolve("Slow!"), 200));

Promise.race([fastPromise, slowPromise])
  .then(result => {
    console.log("First to complete:", result); // "Fast!"
  });

// Promise.allSettled - waits for all promises to settle (resolve or reject)
Promise.allSettled([promise1, promise2, promise3])
  .then(results => {
    results.forEach(result => {
      if (result.status === "fulfilled") {
        console.log("Fulfilled:", result.value);
      } else {
        console.log("Rejected:", result.reason);
      }
    });
  });

// Promise.any - resolves as soon as one promise resolves (ignores rejections)
Promise.any([promise1, promise2, promise3])
  .then(firstResult => {
    console.log("First successful result:", firstResult);
  })
  .catch(error => {
    console.error("All promises rejected:", error);
  });`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Async/Await</h3>
      <p>
        Async/await is syntactic sugar over promises, making asynchronous code look and behave more like synchronous code.
      </p>
      
      <CodeBlock
        language="javascript"
        code={`// Async function declaration
async function fetchUserData() {
  try {
    // Await pauses execution until the promise resolves
    const response = await fetch("https://api.example.com/users/1");
    const userData = await response.json();
    return userData;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw error; // Re-throw to let caller handle it
  }
}

// Using an async function
fetchUserData()
  .then(userData => {
    console.log("User data:", userData);
  })
  .catch(error => {
    console.error("Could not fetch user data:", error);
  });

// Async arrow function
const fetchPosts = async () => {
  try {
    const response = await fetch("https://api.example.com/posts");
    return await response.json();
  } catch (error) {
    console.error("Error:", error);
    return []; // Return empty array on error
  }
};

// Async IIFE (Immediately Invoked Function Expression)
(async () => {
  try {
    const userData = await fetchUserData();
    const posts = await fetchPosts();
    console.log("Data loaded:", userData, posts);
  } catch (error) {
    console.error("Error in IIFE:", error);
  }
})();`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Sequential vs. Parallel with Async/Await</h4>
      <CodeBlock
        language="javascript"
        code={`// Sequential execution (each await waits for the previous to complete)
async function sequentialFetch() {
  console.time("sequential");
  
  const users = await fetch("https://api.example.com/users").then(res => res.json());
  const posts = await fetch("https://api.example.com/posts").then(res => res.json());
  const comments = await fetch("https://api.example.com/comments").then(res => res.json());
  
  console.timeEnd("sequential");
  return { users, posts, comments };
}

// Parallel execution (all fetches start at the same time)
async function parallelFetch() {
  console.time("parallel");
  
  const usersPromise = fetch("https://api.example.com/users").then(res => res.json());
  const postsPromise = fetch("https://api.example.com/posts").then(res => res.json());
  const commentsPromise = fetch("https://api.example.com/comments").then(res => res.json());
  
  const users = await usersPromise;
  const posts = await postsPromise;
  const comments = await commentsPromise;
  
  console.timeEnd("parallel");
  return { users, posts, comments };
}

// Parallel with Promise.all
async function parallelFetchWithPromiseAll() {
  console.time("promise.all");
  
  const [users, posts, comments] = await Promise.all([
    fetch("https://api.example.com/users").then(res => res.json()),
    fetch("https://api.example.com/posts").then(res => res.json()),
    fetch("https://api.example.com/comments").then(res => res.json())
  ]);
  
  console.timeEnd("promise.all");
  return { users, posts, comments };
}`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Error Handling in Async Code</h3>
      <CodeBlock
        language="javascript"
        code={`// Error handling with promises
fetch("https://api.example.com/data")
  .then(response => {
    if (!response.ok) {
      throw new Error("Network response was not ok: " + response.status);
    }
    return response.json();
  })
  .then(data => {
    console.log("Data:", data);
  })
  .catch(error => {
    console.error("Fetch error:", error);
  });

// Error handling with async/await
async function fetchWithErrorHandling() {
  try {
    const response = await fetch("https://api.example.com/data");
    
    if (!response.ok) {
      throw new Error("Network response was not ok: " + response.status);
    }
    
    const data = await response.json();
    console.log("Data:", data);
  } catch (error) {
    if (error instanceof TypeError) {
      console.error("Network error:", error.message);
    } else {
      console.error("Other error:", error.message);
    }
  } finally {
    console.log("Fetch attempt completed");
  }
}

// Creating a reusable fetch utility with error handling
async function fetchJSON(url, options = {}) {
  try {
    const response = await fetch(url, options);
    
    if (!response.ok) {
      throw new Error(\`HTTP error! Status: \${response.status}\`);
    }
    
    return await response.json();
  } catch (error) {
    console.error(\`Error fetching \${url}:\`, error);
    throw error; // Re-throw for the caller to handle
  }
}`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Real-world Asynchronous Patterns</h3>
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Loading Indicator</h4>
      <CodeBlock
        language="javascript"
        code={`async function fetchDataWithLoadingIndicator() {
  const loadingIndicator = document.getElementById("loading");
  const dataContainer = document.getElementById("data");
  
  try {
    // Show loading indicator
    loadingIndicator.style.display = "block";
    dataContainer.innerHTML = "";
    
    // Fetch data
    const response = await fetch("https://api.example.com/data");
    const data = await response.json();
    
    // Render data
    data.forEach(item => {
      const element = document.createElement("div");
      element.textContent = item.name;
      dataContainer.appendChild(element);
    });
  } catch (error) {
    dataContainer.innerHTML = \`<div class="error">Error: \${error.message}</div>\`;
  } finally {
    // Hide loading indicator
    loadingIndicator.style.display = "none";
  }
}`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Debouncing</h4>
      <CodeBlock
        language="javascript"
        code={`// Debounce function to limit how often a function runs
function debounce(func, delay) {
  let timeoutId;
  
  return function(...args) {
    clearTimeout(timeoutId);
    
    timeoutId = setTimeout(() => {
      func.apply(this, args);
    }, delay);
  };
}

// Example: Search as you type with debouncing
const searchInput = document.getElementById("search");

const debouncedSearch = debounce(async (query) => {
  try {
    const response = await fetch(\`https://api.example.com/search?q=\${query}\`);
    const results = await response.json();
    displayResults(results);
  } catch (error) {
    console.error("Search error:", error);
  }
}, 300); // Wait for 300ms after typing stops

searchInput.addEventListener("input", (e) => {
  debouncedSearch(e.target.value);
});`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Retry Pattern</h4>
      <CodeBlock
        language="javascript"
        code={`// Retry a failed operation
async function fetchWithRetry(url, options = {}, retries = 3, delay = 1000) {
  try {
    return await fetch(url, options);
  } catch (error) {
    if (retries <= 0) {
      throw error;
    }
    
    console.warn(\`Fetch failed, retrying in \${delay}ms... (\${retries} retries left)\`);
    
    // Wait before retrying
    await new Promise(resolve => setTimeout(resolve, delay));
    
    // Retry with exponential backoff
    return fetchWithRetry(url, options, retries - 1, delay * 2);
  }
}`}
      />
      
      <h4 className="text-xl font-semibold mt-6 mb-2">Cancellable Fetch with AbortController</h4>
      <CodeBlock
        language="javascript"
        code={`// Cancellable fetch
function fetchWithTimeout(url, options = {}, timeoutMs = 5000) {
  // Create an AbortController instance
  const controller = new AbortController();
  const { signal } = controller;
  
  // Set up timeout
  const timeoutId = setTimeout(() => {
    controller.abort();
  }, timeoutMs);
  
  // Merge signal with existing options
  const fetchOptions = { ...options, signal };
  
  return fetch(url, fetchOptions)
    .then(response => {
      clearTimeout(timeoutId);
      return response;
    })
    .catch(error => {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error(\`Request timed out after \${timeoutMs}ms\`);
      }
      throw error;
    });
}

// Example usage
try {
  const response = await fetchWithTimeout('https://api.example.com/data', {}, 3000);
  const data = await response.json();
  console.log('Data:', data);
} catch (error) {
  console.error('Error:', error.message);
}`}
      />
      
      <h3 className="text-2xl font-semibold mt-8 mb-4">Practical Asynchronous Example</h3>
      <CodeBlock
        language="html"
        code={`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Async JavaScript Demo</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .container {
      border: 1px solid #ddd;
      padding: 20px;
      border-radius: 5px;
      margin-bottom: 20px;
    }
    
    .loading {
      display: none;
      text-align: center;
      padding: 10px;
    }
    
    .loading::after {
      content: "";
      display: inline-block;
      width: 20px;
      height: 20px;
      border: 3px solid #f3f3f3;
      border-top: 3px solid #3498db;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      vertical-align: middle;
      margin-left: 10px;
    }
    
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    
    .error {
      color: red;
      border-left: 3px solid red;
      padding-left: 10px;
      background-color: #ffeeee;
    }
    
    .user-card {
      display: flex;
      padding: 10px;
      border: 1px solid #eee;
      margin-bottom: 10px;
      border-radius: 5px;
    }
    
    .user-card img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 15px;
    }
    
    .posts {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 15px;
    }
    
    .post {
      border: 1px solid #eee;
      padding: 10px;
      border-radius: 5px;
    }
    
    button {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 10px 15px;
      border-radius: 4px;
      cursor: pointer;
      margin-right: 10px;
      margin-bottom: 10px;
    }
    
    button:hover {
      background-color: #45a049;
    }
    
    input {
      padding: 8px;
      margin-right: 10px;
      border-radius: 4px;
      border: 1px solid #ddd;
    }
  </style>
</head>
<body>
  <h1>Asynchronous JavaScript Demo</h1>
  
  <div class="container">
    <h2>Promises vs Async/Await</h2>
    <button id="loadWithPromises">Load With Promises</button>
    <button id="loadWithAsync">Load With Async/Await</button>
    <div id="promiseDemo" class="loading">Loading...</div>
  </div>
  
  <div class="container">
    <h2>User Search</h2>
    <div>
      <input type="text" id="userSearch" placeholder="Search by user ID (1-10)">
      <button id="searchButton">Search</button>
      <button id="cancelSearch">Cancel</button>
    </div>
    <div id="userLoading" class="loading">Loading user...</div>
    <div id="userData"></div>
  </div>
  
  <div class="container">
    <h2>Parallel vs Sequential</h2>
    <button id="loadSequential">Load Sequentially</button>
    <button id="loadParallel">Load in Parallel</button>
    <div id="parallelDemo" class="loading">Loading...</div>
    <div id="loadingResults"></div>
  </div>
  
  <div class="container">
    <h2>Retry Pattern</h2>
    <button id="successButton">Successful Request</button>
    <button id="failButton">Failed Request with Retry</button>
    <div id="retryLoading" class="loading">Loading...</div>
    <div id="retryResults"></div>
  </div>
  
  <script>
    // Helper function to simulate fetch with artificial delay and error rate
    function fakeFetch(url, { failRate = 0, delay = 500 } = {}) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          // Simulate random failure
          if (Math.random() < failRate) {
            reject(new Error("Network request failed"));
            return;
          }
          
          // User endpoint
          if (url.includes("users")) {
            const userId = url.split("/").pop();
            resolve({
              ok: true,
              json: () => Promise.resolve({
                id: userId,
                name: \`User \${userId}\`,
                email: \`user\${userId}@example.com\`,
                avatar: \`https://randomuser.me/api/portraits/men/\${userId}.jpg\`
              })
            });
          }
          // Posts endpoint
          else if (url.includes("posts")) {
            const userId = new URL(url).searchParams.get("userId");
            const posts = [];
            
            for (let i = 1; i <= 3; i++) {
              posts.push({
                id: i,
                userId: userId,
                title: \`Post \${i} by User \${userId}\`,
                body: \`This is the content of post \${i} written by user \${userId}...\`
              });
            }
            
            resolve({
              ok: true,
              json: () => Promise.resolve(posts)
            });
          }
          // Comments endpoint
          else if (url.includes("comments")) {
            resolve({
              ok: true,
              json: () => Promise.resolve([
                { id: 1, body: "Comment 1" },
                { id: 2, body: "Comment 2" },
                { id: 3, body: "Comment 3" }
              ])
            });
          }
          else {
            resolve({
              ok: true,
              json: () => Promise.resolve({ message: "Success" })
            });
          }
        }, delay);
      });
    }
    
    // Helper to retry failed requests
    async function fetchWithRetry(url, options = {}, retries = 3, delay = 1000) {
      const { failRate, ...fetchOptions } = options;
      
      try {
        const result = await fakeFetch(url, { failRate, delay: 500 });
        return result;
      } catch (error) {
        if (retries <= 0) {
          throw error;
        }
        
        document.getElementById("retryResults").innerHTML += \`
          <p>Attempt failed. Retrying in \${delay}ms... (\${retries} retries left)</p>
        \`;
        
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, delay));
        
        // Retry with exponential backoff
        return fetchWithRetry(url, options, retries - 1, delay * 2);
      }
    }
    
    // Promise approach to loading user and posts
    function loadUserWithPromises(userId) {
      const promiseDemo = document.getElementById("promiseDemo");
      promiseDemo.style.display = "block";
      promiseDemo.classList.add("loading");
      promiseDemo.textContent = "Loading...";
      
      fakeFetch(\`https://api.example.com/users/\${userId}\`)
        .then(response => response.json())
        .then(user => {
          promiseDemo.innerHTML = \`
            <div class="user-card">
              <img src="\${user.avatar}" alt="\${user.name}">
              <div>
                <h3>\${user.name}</h3>
                <p>\${user.email}</p>
              </div>
            </div>
            <h3>Posts</h3>
            <div class="posts" id="userPosts">Loading posts...</div>
          \`;
          
          return fakeFetch(\`https://api.example.com/posts?userId=\${user.id}\`);
        })
        .then(response => response.json())
        .then(posts => {
          const postsContainer = document.getElementById("userPosts");
          let postsHtml = "";
          
          posts.forEach(post => {
            postsHtml += \`
              <div class="post">
                <h4>\${post.title}</h4>
                <p>\${post.body}</p>
              </div>
            \`;
          });
          
          postsContainer.innerHTML = postsHtml;
        })
        .catch(error => {
          promiseDemo.innerHTML = \`<div class="error">Error: \${error.message}</div>\`;
        })
        .finally(() => {
          promiseDemo.classList.remove("loading");
        });
    }
    
    // Async/await approach to loading user and posts
    async function loadUserWithAsync(userId) {
      const promiseDemo = document.getElementById("promiseDemo");
      promiseDemo.style.display = "block";
      promiseDemo.classList.add("loading");
      promiseDemo.textContent = "Loading...";
      
      try {
        // Fetch user data
        const userResponse = await fakeFetch(\`https://api.example.com/users/\${userId}\`);
        const user = await userResponse.json();
        
        promiseDemo.innerHTML = \`
          <div class="user-card">
            <img src="\${user.avatar}" alt="\${user.name}">
            <div>
              <h3>\${user.name}</h3>
              <p>\${user.email}</p>
            </div>
          </div>
          <h3>Posts</h3>
          <div class="posts" id="userPosts">Loading posts...</div>
        \`;
        
        // Fetch user's posts
        const postsResponse = await fakeFetch(\`https://api.example.com/posts?userId=\${user.id}\`);
        const posts = await postsResponse.json();
        
        const postsContainer = document.getElementById("userPosts");
        let postsHtml = "";
        
        posts.forEach(post => {
          postsHtml += \`
            <div class="post">
              <h4>\${post.title}</h4>
              <p>\${post.body}</p>
            </div>
          \`;
        });
        
        postsContainer.innerHTML = postsHtml;
        
      } catch (error) {
        promiseDemo.innerHTML = \`<div class="error">Error: \${error.message}</div>\`;
      } finally {
        promiseDemo.classList.remove("loading");
      }
    }
    
    // User search with cancellation
    let controller = null; // Store the AbortController
    
    async function searchUser(userId) {
      const userLoading = document.getElementById("userLoading");
      const userData = document.getElementById("userData");
      
      // Clear previous results
      userData.innerHTML = "";
      userLoading.style.display = "block";
      
      // Create new AbortController
      controller = new AbortController();
      const { signal } = controller;
      
      try {
        // Add artificial delay to demonstrate cancellation
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Check if cancelled
        if (signal.aborted) return;
        
        // Fetch user
        const response = await fakeFetch(\`https://api.example.com/users/\${userId}\`);
        const user = await response.json();
        
        // Check if cancelled
        if (signal.aborted) return;
        
        userData.innerHTML = \`
          <div class="user-card">
            <img src="\${user.avatar}" alt="\${user.name}">
            <div>
              <h3>\${user.name}</h3>
              <p>\${user.email}</p>
            </div>
          </div>
        \`;
      } catch (error) {
        if (error.name === "AbortError") {
          userData.innerHTML = "<p>Search was cancelled</p>";
        } else {
          userData.innerHTML = \`<div class="error">Error: \${error.message}</div>\`;
        }
      } finally {
        userLoading.style.display = "none";
      }
    }
    
    // Sequential loading
    async function loadSequentially() {
      const parallelDemo = document.getElementById("parallelDemo");
      const loadingResults = document.getElementById("loadingResults");
      
      parallelDemo.style.display = "block";
      loadingResults.innerHTML = "<h3>Sequential Loading:</h3>";
      
      const startTime = Date.now();
      
      try {
        loadingResults.innerHTML += "<p>Loading users...</p>";
        const usersResponse = await fakeFetch("https://api.example.com/users");
        const users = await usersResponse.json();
        loadingResults.innerHTML += "<p>Users loaded!</p>";
        
        loadingResults.innerHTML += "<p>Loading posts...</p>";
        const postsResponse = await fakeFetch("https://api.example.com/posts");
        const posts = await postsResponse.json();
        loadingResults.innerHTML += "<p>Posts loaded!</p>";
        
        loadingResults.innerHTML += "<p>Loading comments...</p>";
        const commentsResponse = await fakeFetch("https://api.example.com/comments");
        const comments = await commentsResponse.json();
        loadingResults.innerHTML += "<p>Comments loaded!</p>";
        
        const endTime = Date.now();
        loadingResults.innerHTML += \`<p><strong>Total time: \${endTime - startTime}ms</strong></p>\`;
        
      } catch (error) {
        loadingResults.innerHTML += \`<div class="error">Error: \${error.message}</div>\`;
      } finally {
        parallelDemo.style.display = "none";
      }
    }
    
    // Parallel loading
    async function loadInParallel() {
      const parallelDemo = document.getElementById("parallelDemo");
      const loadingResults = document.getElementById("loadingResults");
      
      parallelDemo.style.display = "block";
      loadingResults.innerHTML = "<h3>Parallel Loading:</h3>";
      
      const startTime = Date.now();
      
      try {
        loadingResults.innerHTML += "<p>Loading all data in parallel...</p>";
        
        // Start all fetches in parallel
        const usersPromise = fakeFetch("https://api.example.com/users")
          .then(res => res.json());
        
        const postsPromise = fakeFetch("https://api.example.com/posts")
          .then(res => res.json());
        
        const commentsPromise = fakeFetch("https://api.example.com/comments")
          .then(res => res.json());
        
        // Wait for all to complete
        const [users, posts, comments] = await Promise.all([
          usersPromise, postsPromise, commentsPromise
        ]);
        
        loadingResults.innerHTML += "<p>All data loaded!</p>";
        
        const endTime = Date.now();
        loadingResults.innerHTML += \`<p><strong>Total time: \${endTime - startTime}ms</strong></p>\`;
        
      } catch (error) {
        loadingResults.innerHTML += \`<div class="error">Error: \${error.message}</div>\`;
      } finally {
        parallelDemo.style.display = "none";
      }
    }
    
    // Retry demonstration
    async function handleSuccessfulRequest() {
      const retryLoading = document.getElementById("retryLoading");
      const retryResults = document.getElementById("retryResults");
      
      retryLoading.style.display = "block";
      retryResults.innerHTML = "<h3>Successful Request:</h3>";
      
      try {
        const response = await fakeFetch("https://api.example.com/data");
        const data = await response.json();
        
        retryResults.innerHTML += \`<p>Request succeeded: \${data.message}</p>\`;
      } catch (error) {
        retryResults.innerHTML += \`<div class="error">Error: \${error.message}</div>\`;
      } finally {
        retryLoading.style.display = "none";
      }
    }
    
    async function handleFailedRequest() {
      const retryLoading = document.getElementById("retryLoading");
      const retryResults = document.getElementById("retryResults");
      
      retryLoading.style.display = "block";
      retryResults.innerHTML = "<h3>Request with Retries:</h3>";
      
      try {
        // Set high fail rate to demonstrate retry
        const response = await fetchWithRetry(
          "https://api.example.com/data", 
          { failRate: 0.8 }, // 80% chance to fail
          3, // 3 retries
          1000 // 1 second initial delay
        );
        const data = await response.json();
        
        retryResults.innerHTML += \`<p>Request eventually succeeded: \${data.message}</p>\`;
      } catch (error) {
        retryResults.innerHTML += \`<div class="error">All retries failed: \${error.message}</div>\`;
      } finally {
        retryLoading.style.display = "none";
      }
    }
    
    // Set up event listeners
    document.getElementById("loadWithPromises").addEventListener("click", () => {
      loadUserWithPromises(1);
    });
    
    document.getElementById("loadWithAsync").addEventListener("click", () => {
      loadUserWithAsync(2);
    });
    
    document.getElementById("searchButton").addEventListener("click", () => {
      const userId = document.getElementById("userSearch").value;
      if (userId && userId >= 1 && userId <= 10) {
        searchUser(userId);
      } else {
        document.getElementById("userData").innerHTML = 
          '<div class="error">Please enter a valid user ID (1-10)</div>';
      }
    });
    
    document.getElementById("cancelSearch").addEventListener("click", () => {
      if (controller) {
        controller.abort();
        document.getElementById("userLoading").style.display = "none";
      }
    });
    
    document.getElementById("loadSequential").addEventListener("click", loadSequentially);
    document.getElementById("loadParallel").addEventListener("click", loadInParallel);
    document.getElementById("successButton").addEventListener("click", handleSuccessfulRequest);
    document.getElementById("failButton").addEventListener("click", handleFailedRequest);
  </script>
</body>
</html>`}
      />
      
      <div className="glass p-6 my-6 bg-yellow-50 dark:bg-yellow-900 dark:bg-opacity-20">
        <h4 className="text-lg font-semibold mb-2">Asynchronous JavaScript Best Practices</h4>
        <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
          <li>Prefer async/await over raw promises for readability, but understand promises underneath</li>
          <li>Always handle errors in asynchronous code using try/catch or .catch()</li>
          <li>Run independent asynchronous operations in parallel when possible</li>
          <li>Use Promise.all() for multiple operations that can run in parallel</li>
          <li>Implement timeouts for network requests to avoid hanging operations</li>
          <li>Consider cancellation for long-running operations or user-initiated cancellations</li>
          <li>Avoid deeply nested async/await calls; extract functions for better readability</li>
          <li>Use appropriate loading indicators for better user experience during async operations</li>
          <li>Consider implementing retry logic for operations that might fail temporarily</li>
          <li>Remember that async functions always return Promises</li>
        </ul>
      </div>
      
      <p>
        Asynchronous JavaScript is fundamental to modern web development. Whether you're fetching data from an API, handling user interactions, or implementing animations, these patterns and techniques will help you write more efficient, responsive, and robust applications.
      </p>
    </>
  ];

  return (
    <div className="py-8">
      <h1 className="text-center mb-8">JavaScript Tutorial</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-1">
          <ProgressTracker 
            steps={steps} 
            currentStep={currentStep} 
            onStepChange={setCurrentStep} 
          />
        </div>
        
        <div className="md:col-span-3">
          <div className="glass p-8">
            {tutorialContent[currentStep]}
            
            <div className="flex justify-between mt-12">
              <button
                onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                className={`btn ${
                  currentStep === 0
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
                }`}
                disabled={currentStep === 0}
              >
                Previous
              </button>
              
              <button
                onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
                className={`btn ${
                  currentStep === steps.length - 1
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    : 'btn-primary'
                }`}
                disabled={currentStep === steps.length - 1}
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JsTutorial;