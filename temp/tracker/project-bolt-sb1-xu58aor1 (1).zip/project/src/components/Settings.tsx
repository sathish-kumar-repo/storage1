import React, { useState } from 'react';
import { Settings as SettingsIcon, RotateCcw, Download, Upload, Trash2, AlertTriangle } from 'lucide-react';
import { TrackerData } from '../types';
import { ResetConfirmation } from './ResetConfirmation';

interface SettingsProps {
  trackerData: TrackerData;
  onReset: () => void;
  onImportData: (data: TrackerData) => void;
}

export function Settings({ trackerData, onReset, onImportData }: SettingsProps) {
  const [showResetModal, setShowResetModal] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  const handleExportData = () => {
    const dataStr = JSON.stringify(trackerData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nofab-tracker-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedData = JSON.parse(e.target?.result as string);
        
        // Validate the imported data structure
        if (!importedData.startDate || !importedData.dailyChecks || !Array.isArray(importedData.milestones)) {
          throw new Error('Invalid data format');
        }
        
        onImportData(importedData);
        setImportError(null);
      } catch (error) {
        setImportError('Invalid file format. Please select a valid backup file.');
      }
    };
    reader.readAsText(file);
    
    // Reset the input
    event.target.value = '';
  };

  const handleClearData = () => {
    if (confirm('Are you sure you want to clear all data? This action cannot be undone.')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-500 to-gray-700 rounded-2xl p-8 text-white">
        <div className="flex items-center space-x-4">
          <div className="p-3 rounded-full bg-white/20">
            <SettingsIcon className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-2">Settings</h1>
            <p className="text-gray-200">
              Manage your tracker preferences and data
            </p>
          </div>
        </div>
      </div>

      {/* Settings Sections */}
      <div className="grid gap-8">
        {/* Data Management */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6">
            Data Management
          </h2>
          <div className="space-y-6">
            {/* Export Data */}
            <div className="flex items-center justify-between p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
              <div className="flex items-center space-x-4">
                <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-800/30">
                  <Download className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Export Data</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Download a backup of all your tracking data
                  </p>
                </div>
              </div>
              <button
                onClick={handleExportData}
                className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors duration-200"
              >
                Export
              </button>
            </div>

            {/* Import Data */}
            <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-xl">
              <div className="flex items-center space-x-4">
                <div className="p-2 rounded-full bg-green-100 dark:bg-green-800/30">
                  <Upload className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Import Data</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Restore data from a backup file
                  </p>
                </div>
              </div>
              <label className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors duration-200 cursor-pointer">
                Import
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportData}
                  className="hidden"
                />
              </label>
            </div>

            {importError && (
              <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400" />
                  <p className="text-red-700 dark:text-red-300 text-sm">{importError}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Danger Zone */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-red-200 dark:border-red-800">
          <h2 className="text-xl font-bold text-red-600 dark:text-red-400 mb-6">
            Danger Zone
          </h2>
          <div className="space-y-6">
            {/* Reset Streak */}
            <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/20 rounded-xl">
              <div className="flex items-center space-x-4">
                <div className="p-2 rounded-full bg-red-100 dark:bg-red-800/30">
                  <RotateCcw className="w-5 h-5 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Reset Streak</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Reset your current streak and start over
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowResetModal(true)}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors duration-200"
              >
                Reset
              </button>
            </div>

            {/* Clear All Data */}
            <div className="flex items-center justify-between p-4 bg-red-50 dark:bg-red-900/20 rounded-xl">
              <div className="flex items-center space-x-4">
                <div className="p-2 rounded-full bg-red-100 dark:bg-red-800/30">
                  <Trash2 className="w-5 h-5 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Clear All Data</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Permanently delete all tracking data
                  </p>
                </div>
              </div>
              <button
                onClick={handleClearData}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors duration-200"
              >
                Clear
              </button>
            </div>
          </div>
        </div>

        {/* Statistics */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6">
            Statistics
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                {trackerData.totalDays}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Total Days</div>
            </div>
            <div className="text-center p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {trackerData.totalSuccessfulDays}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Successful</div>
            </div>
            <div className="text-center p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {trackerData.currentStreak}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Current Streak</div>
            </div>
            <div className="text-center p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
              <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                {trackerData.longestStreak}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Best Streak</div>
            </div>
          </div>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      <ResetConfirmation
        isOpen={showResetModal}
        onClose={() => setShowResetModal(false)}
        onConfirm={() => {
          onReset();
          setShowResetModal(false);
        }}
      />
    </div>
  );
}