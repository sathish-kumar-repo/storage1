import React from 'react';
import { Flame, TrendingUp, Award, RefreshCw, Calendar, Target } from 'lucide-react';
import { TrackerData } from '../types';
import { ProgressCircle } from './ProgressCircle';
import { StatCard } from './StatCard';
import { QuoteCard } from './QuoteCard';
import { FirebaseSetup } from './FirebaseSetup';
import { motivationalQuotes } from '../data/quotes';
import { useAuth } from '../hooks/useAuth';

interface DashboardProps {
  trackerData: TrackerData;
}

export function Dashboard({ trackerData }: DashboardProps) {
  const { user } = useAuth();
  const progressPercentage = Math.min((trackerData.currentStreak / 365) * 100, 100);
  const achievedMilestones = trackerData.milestones.filter(m => m.achieved).length;
  const randomQuote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
  const successRate = Math.round((trackerData.totalSuccessfulDays / Math.max(trackerData.totalDays, 1)) * 100);

  const getTimeDetails = () => {
    const now = new Date();
    const start = new Date(trackerData.startDate);
    const diffTime = now.getTime() - start.getTime();
    
    const days = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diffTime % (1000 * 60 * 60)) / (1000 * 60));
    
    return { days, hours, minutes };
  };

  const timeDetails = getTimeDetails();

  return (
    <div className="space-y-8">
      {/* Firebase Setup Notice */}
      {!user && <FirebaseSetup />}

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-500 via-purple-600 to-indigo-600 rounded-3xl p-8 text-white">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl font-bold mb-4">
              {user ? `Welcome back, ${user.email?.split('@')[0]}!` : 'Welcome Back!'}
            </h1>
            <p className="text-blue-100 text-lg mb-6">
              You're on day <span className="font-bold text-white">{trackerData.currentStreak}</span> of your journey. 
              Keep up the excellent work!
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 rounded-xl p-4 backdrop-blur-sm">
                <div className="text-2xl font-bold">{successRate}%</div>
                <div className="text-blue-100 text-sm">Success Rate</div>
              </div>
              <div className="bg-white/10 rounded-xl p-4 backdrop-blur-sm">
                <div className="text-2xl font-bold">{trackerData.totalDays}</div>
                <div className="text-blue-100 text-sm">Total Days</div>
              </div>
            </div>
          </div>
          <div className="flex justify-center">
            <ProgressCircle progress={progressPercentage} size={280}>
              <div className="text-center">
                <div className="text-5xl font-bold text-white mb-2">
                  {trackerData.currentStreak}
                </div>
                <div className="text-blue-100 font-medium text-lg">
                  {trackerData.currentStreak === 1 ? 'Day' : 'Days'}
                </div>
                <div className="text-sm text-blue-200 mt-2">
                  {timeDetails.hours}h {timeDetails.minutes}m
                </div>
              </div>
            </ProgressCircle>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Current Streak"
          value={`${trackerData.currentStreak} days`}
          icon={Flame}
          color="blue"
        />
        <StatCard
          title="Longest Streak"
          value={`${trackerData.longestStreak} days`}
          icon={TrendingUp}
          color="green"
        />
        <StatCard
          title="Milestones"
          value={`${achievedMilestones}/${trackerData.milestones.length}`}
          icon={Award}
          color="amber"
        />
        <StatCard
          title="Success Rate"
          value={`${successRate}%`}
          icon={Target}
          color="purple"
        />
      </div>

      {/* Content Grid */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent Milestones */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center space-x-3">
            <Award className="w-6 h-6 text-amber-500" />
            <span>Recent Achievements</span>
          </h2>
          <div className="space-y-4">
            {trackerData.milestones
              .filter(m => m.achieved)
              .slice(-3)
              .map((milestone) => (
                <div key={milestone.day} className="flex items-center space-x-4 p-4 bg-green-50 dark:bg-green-900/20 rounded-xl">
                  <div className="p-2 rounded-full bg-green-100 dark:bg-green-800/30">
                    <Award className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 dark:text-gray-100">{milestone.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Day {milestone.day}</p>
                  </div>
                </div>
              ))}
            {trackerData.milestones.filter(m => m.achieved).length === 0 && (
              <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                No achievements yet. Keep going to unlock your first milestone!
              </p>
            )}
          </div>
        </div>

        {/* Daily Motivation */}
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center space-x-3">
              <Calendar className="w-6 h-6 text-blue-500" />
              <span>Daily Motivation</span>
            </h2>
            <QuoteCard quote={randomQuote} />
          </div>

          {/* Next Milestone */}
          {(() => {
            const nextMilestone = trackerData.milestones.find(m => !m.achieved);
            if (nextMilestone) {
              return (
                <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl p-6 text-white">
                  <h3 className="font-bold text-lg mb-2">Next Milestone</h3>
                  <p className="text-purple-100 mb-4">{nextMilestone.title}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-purple-200">
                      {nextMilestone.day - trackerData.currentStreak} days to go
                    </span>
                    <div className="text-right">
                      <div className="text-2xl font-bold">Day {nextMilestone.day}</div>
                    </div>
                  </div>
                </div>
              );
            }
            return null;
          })()}
        </div>
      </div>
    </div>
  );
}