import React, { useState } from 'react';
import { Heart, Github, Twitter, Mail, Shield, FileText, ExternalLink, X } from 'lucide-react';

export function Footer() {
  const [showModal, setShowModal] = useState<string | null>(null);
  const currentYear = new Date().getFullYear();

  const Modal = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white dark:bg-gray-800 rounded-xl p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{title}</h2>
          <button
            onClick={() => setShowModal(null)}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <div className="prose dark:prose-invert max-w-none">
          {children}
        </div>
      </div>
    </div>
  );

  return (
    <>
      <footer className="bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-2 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">
                    NoFab Tracker Pro
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Professional Journey Tracking
                  </p>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed mb-4">
                Empowering individuals on their personal development journey with professional-grade 
                tracking tools, analytics, and motivational support. Your privacy and progress matter to us.
              </p>
              <div className="flex items-center space-x-4">
                <a
                  href="https://github.com/nofab-tracker"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                  aria-label="GitHub"
                >
                  <Github className="w-5 h-5" />
                </a>
                <a
                  href="https://twitter.com/nofabtracker"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                  aria-label="Twitter"
                >
                  <Twitter className="w-5 h-5" />
                </a>
                <a
                  href="mailto:support@nofabtracker.com"
                  className="text-gray-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
                  aria-label="Email"
                >
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100 uppercase tracking-wider mb-4">
                Quick Links
              </h4>
              <ul className="space-y-3">
                <li>
                  <button 
                    onClick={() => setShowModal('getting-started')}
                    className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm transition-colors flex items-center space-x-1"
                  >
                    <span>Getting Started</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowModal('user-guide')}
                    className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm transition-colors flex items-center space-x-1"
                  >
                    <span>User Guide</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowModal('faq')}
                    className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm transition-colors flex items-center space-x-1"
                  >
                    <span>FAQ</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </li>
                <li>
                  <a 
                    href="mailto:support@nofabtracker.com"
                    className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm transition-colors flex items-center space-x-1"
                  >
                    <span>Support</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100 uppercase tracking-wider mb-4">
                Legal
              </h4>
              <ul className="space-y-3">
                <li>
                  <button 
                    onClick={() => setShowModal('privacy')}
                    className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm transition-colors flex items-center space-x-2"
                  >
                    <FileText className="w-3 h-3" />
                    <span>Privacy Policy</span>
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowModal('terms')}
                    className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm transition-colors flex items-center space-x-2"
                  >
                    <FileText className="w-3 h-3" />
                    <span>Terms of Service</span>
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowModal('security')}
                    className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 text-sm transition-colors flex items-center space-x-2"
                  >
                    <Shield className="w-3 h-3" />
                    <span>Data Security</span>
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-200 dark:border-gray-800 mt-8 pt-8">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <p className="text-gray-500 dark:text-gray-400 text-sm">
                © {currentYear} NoFab Tracker Pro. All rights reserved.
              </p>
              <p className="text-gray-500 dark:text-gray-400 text-sm flex items-center space-x-1 mt-2 md:mt-0">
                <span>Made with</span>
                <Heart className="w-4 h-4 text-red-500" />
                <span>for personal growth</span>
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals */}
      {showModal === 'getting-started' && (
        <Modal title="Getting Started">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Welcome to NoFab Tracker Pro!</h3>
            <p>Follow these simple steps to begin your journey:</p>
            <ol className="list-decimal list-inside space-y-2">
              <li><strong>Set Your Start Date:</strong> Your journey begins today, but you can adjust the start date in settings if needed.</li>
              <li><strong>Daily Check-ins:</strong> Visit the Daily Tracker tab each day to mark your progress.</li>
              <li><strong>Track Your Progress:</strong> Use the Analytics tab to view detailed insights about your journey.</li>
              <li><strong>Celebrate Milestones:</strong> Check the Milestones tab to see your achievements and upcoming goals.</li>
              <li><strong>Stay Motivated:</strong> Read daily quotes and track your streak on the Dashboard.</li>
            </ol>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Remember: Progress isn't always linear. Be kind to yourself and focus on long-term growth.
            </p>
          </div>
        </Modal>
      )}

      {showModal === 'user-guide' && (
        <Modal title="User Guide">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">How to Use NoFab Tracker Pro</h3>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Dashboard</h4>
              <p>Your main hub showing current streak, success rate, recent achievements, and daily motivation.</p>
              
              <h4 className="font-semibold">Daily Tracker</h4>
              <p>Mark each day as successful or not. You can only check days from your start date to today. Future dates are blocked.</p>
              
              <h4 className="font-semibold">Analytics</h4>
              <p>View detailed charts and statistics about your progress, including weekly success rates and streak patterns.</p>
              
              <h4 className="font-semibold">Milestones</h4>
              <p>Track your achievements at key intervals (1, 7, 30, 60, 90, 180, and 365 days).</p>
              
              <h4 className="font-semibold">Settings</h4>
              <p>Export/import your data, reset your streak, or clear all data. Use the export feature to backup your progress.</p>
            </div>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-800 dark:text-blue-200">Pro Tips:</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-blue-700 dark:text-blue-300">
                <li>Check in daily for the best tracking experience</li>
                <li>Use the analytics to identify patterns in your behavior</li>
                <li>Export your data regularly as a backup</li>
                <li>Focus on progress, not perfection</li>
              </ul>
            </div>
          </div>
        </Modal>
      )}

      {showModal === 'faq' && (
        <Modal title="Frequently Asked Questions">
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold">Q: Can I change my start date?</h4>
              <p className="text-sm">A: Yes, you can reset your journey in the Settings tab, which will set a new start date to today.</p>
            </div>
            
            <div>
              <h4 className="font-semibold">Q: What happens if I miss a day?</h4>
              <p className="text-sm">A: You can mark previous days (after your start date) as successful or failed. Your streak will be calculated based on consecutive successful days.</p>
            </div>
            
            <div>
              <h4 className="font-semibold">Q: Is my data private?</h4>
              <p className="text-sm">A: Yes, all data is stored locally in your browser and optionally synced with your Firebase account if you're logged in. We don't share your personal data.</p>
            </div>
            
            <div>
              <h4 className="font-semibold">Q: Can I use this on multiple devices?</h4>
              <p className="text-sm">A: Yes, if you create an account and sign in, your data will sync across all your devices.</p>
            </div>
            
            <div>
              <h4 className="font-semibold">Q: How do I backup my data?</h4>
              <p className="text-sm">A: Go to Settings and use the "Export Data" feature to download a backup file. You can later import this file to restore your data.</p>
            </div>
            
            <div>
              <h4 className="font-semibold">Q: What if I accidentally reset my streak?</h4>
              <p className="text-sm">A: Unfortunately, resets cannot be undone. However, your previous longest streak is always preserved in your statistics.</p>
            </div>
          </div>
        </Modal>
      )}

      {showModal === 'privacy' && (
        <Modal title="Privacy Policy">
          <div className="space-y-4">
            <p className="text-sm text-gray-600 dark:text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
            
            <h3 className="text-lg font-semibold">Information We Collect</h3>
            <p>We collect minimal information necessary to provide our service:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Account information (email address) if you choose to create an account</li>
              <li>Progress tracking data (check-ins, streaks, milestones)</li>
              <li>Usage analytics to improve our service</li>
            </ul>
            
            <h3 className="text-lg font-semibold">How We Use Your Information</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>To provide and maintain our tracking service</li>
              <li>To sync your data across devices (if logged in)</li>
              <li>To send important service updates</li>
              <li>To improve our application based on usage patterns</li>
            </ul>
            
            <h3 className="text-lg font-semibold">Data Storage</h3>
            <p>Your data is stored securely using Firebase services. Local data is stored in your browser's local storage.</p>
            
            <h3 className="text-lg font-semibold">Data Sharing</h3>
            <p>We do not sell, trade, or share your personal information with third parties. Your tracking data remains private.</p>
            
            <h3 className="text-lg font-semibold">Contact Us</h3>
            <p>If you have questions about this Privacy Policy, contact us at privacy@nofabtracker.com</p>
          </div>
        </Modal>
      )}

      {showModal === 'terms' && (
        <Modal title="Terms of Service">
          <div className="space-y-4">
            <p className="text-sm text-gray-600 dark:text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
            
            <h3 className="text-lg font-semibold">Acceptance of Terms</h3>
            <p>By using NoFab Tracker Pro, you agree to these terms of service.</p>
            
            <h3 className="text-lg font-semibold">Description of Service</h3>
            <p>NoFab Tracker Pro is a personal development tracking application that helps users monitor their progress on personal goals.</p>
            
            <h3 className="text-lg font-semibold">User Responsibilities</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>Provide accurate information when creating an account</li>
              <li>Keep your account credentials secure</li>
              <li>Use the service for its intended purpose</li>
              <li>Respect other users and our community guidelines</li>
            </ul>
            
            <h3 className="text-lg font-semibold">Prohibited Uses</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>Using the service for illegal activities</li>
              <li>Attempting to hack or compromise the service</li>
              <li>Sharing inappropriate content</li>
              <li>Creating multiple accounts to circumvent limitations</li>
            </ul>
            
            <h3 className="text-lg font-semibold">Limitation of Liability</h3>
            <p>NoFab Tracker Pro is provided "as is" without warranties. We are not liable for any damages arising from use of the service.</p>
            
            <h3 className="text-lg font-semibold">Changes to Terms</h3>
            <p>We may update these terms at any time. Continued use of the service constitutes acceptance of new terms.</p>
          </div>
        </Modal>
      )}

      {showModal === 'security' && (
        <Modal title="Data Security">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Our Security Commitment</h3>
            <p>We take the security of your personal data seriously and implement industry-standard measures to protect it.</p>
            
            <h3 className="text-lg font-semibold">Data Encryption</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>All data transmission is encrypted using HTTPS/TLS</li>
              <li>Stored data is encrypted at rest using Firebase security</li>
              <li>Authentication is handled securely through Firebase Auth</li>
            </ul>
            
            <h3 className="text-lg font-semibold">Access Controls</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>Only you can access your personal tracking data</li>
              <li>We use role-based access controls for our systems</li>
              <li>Regular security audits and updates</li>
            </ul>
            
            <h3 className="text-lg font-semibold">Data Backup</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>Regular automated backups of all data</li>
              <li>You can export your own data at any time</li>
              <li>Disaster recovery procedures in place</li>
            </ul>
            
            <h3 className="text-lg font-semibold">Incident Response</h3>
            <p>In the unlikely event of a security incident, we will:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Immediately investigate and contain the issue</li>
              <li>Notify affected users within 72 hours</li>
              <li>Provide clear information about what happened</li>
              <li>Take steps to prevent future incidents</li>
            </ul>
            
            <h3 className="text-lg font-semibold">Your Security</h3>
            <p>Help us keep your account secure by:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Using a strong, unique password</li>
              <li>Not sharing your account credentials</li>
              <li>Logging out on shared devices</li>
              <li>Reporting suspicious activity</li>
            </ul>
          </div>
        </Modal>
      )}
    </>
  );
}