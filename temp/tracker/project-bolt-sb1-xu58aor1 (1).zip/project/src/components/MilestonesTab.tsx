import React from 'react';
import { Trophy, Lock, Calendar, Award } from 'lucide-react';
import { TrackerData } from '../types';
import { MilestoneCard } from './MilestoneCard';

interface MilestonesTabProps {
  trackerData: TrackerData;
}

export function MilestonesTab({ trackerData }: MilestonesTabProps) {
  const achievedMilestones = trackerData.milestones.filter(m => m.achieved);
  const upcomingMilestones = trackerData.milestones.filter(m => !m.achieved);
  const nextMilestone = upcomingMilestones[0];

  return (
    <div className="space-y-8">
      {/* Progress Overview */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Milestone Progress</h1>
            <p className="text-amber-100 mb-4">
              Track your achievements and celebrate your progress
            </p>
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5" />
                <span className="font-medium">Achieved: {achievedMilestones.length}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Lock className="w-5 h-5" />
                <span className="font-medium">Remaining: {upcomingMilestones.length}</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold">{achievedMilestones.length}</div>
            <div className="text-amber-100">/ {trackerData.milestones.length}</div>
          </div>
        </div>
      </div>

      {/* Next Milestone Highlight */}
      {nextMilestone && (
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center space-x-3">
            <Award className="w-6 h-6 text-blue-500" />
            <span>Next Milestone</span>
          </h2>
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl p-6 border border-blue-200 dark:border-blue-800">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                  {nextMilestone.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  {nextMilestone.description}
                </p>
                <div className="flex items-center space-x-4">
                  <span className="px-3 py-1 bg-blue-100 dark:bg-blue-800/30 text-blue-700 dark:text-blue-300 rounded-full text-sm font-medium">
                    Day {nextMilestone.day}
                  </span>
                  <span className="text-gray-500 dark:text-gray-400 text-sm">
                    {nextMilestone.day - trackerData.currentStreak} days to go
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-800/30 flex items-center justify-center">
                  <Lock className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* All Milestones */}
      <div className="grid gap-8">
        {/* Achieved Milestones */}
        {achievedMilestones.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center space-x-3">
              <Trophy className="w-6 h-6 text-green-500" />
              <span>Achieved Milestones ({achievedMilestones.length})</span>
            </h2>
            <div className="grid gap-4">
              {achievedMilestones.map((milestone) => (
                <MilestoneCard key={milestone.day} milestone={milestone} />
              ))}
            </div>
          </div>
        )}

        {/* Upcoming Milestones */}
        {upcomingMilestones.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center space-x-3">
              <Calendar className="w-6 h-6 text-gray-500" />
              <span>Upcoming Milestones ({upcomingMilestones.length})</span>
            </h2>
            <div className="grid gap-4">
              {upcomingMilestones.map((milestone, index) => (
                <MilestoneCard 
                  key={milestone.day} 
                  milestone={milestone} 
                  isNext={index === 0}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}