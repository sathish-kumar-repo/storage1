import React from 'react';
import { Quote } from 'lucide-react';
import { Quote as QuoteType } from '../types';

interface QuoteCardProps {
  quote: QuoteType;
}

export function QuoteCard({ quote }: QuoteCardProps) {
  return (
    <div className="p-6 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border border-blue-100 dark:border-blue-800/50">
      <div className="flex items-start space-x-4">
        <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-800/30">
          <Quote className="w-5 h-5 text-blue-600 dark:text-blue-400" />
        </div>
        <div className="flex-1">
          <blockquote className="text-gray-700 dark:text-gray-300 italic leading-relaxed mb-3">
            "{quote.text}"
          </blockquote>
          <cite className="text-blue-600 dark:text-blue-400 font-medium text-sm">
            — {quote.author}
          </cite>
        </div>
      </div>
    </div>
  );
}