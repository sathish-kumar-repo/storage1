import React from 'react';

interface CalendarProps {
  startDate: string;
  currentStreak: number;
}

export function Calendar({ startDate, currentStreak }: CalendarProps) {
  const start = new Date(startDate);
  const today = new Date();
  const daysInYear = 365;
  
  const getDayStatus = (dayIndex: number) => {
    const currentDay = new Date(start);
    currentDay.setDate(currentDay.getDate() + dayIndex);
    
    if (currentDay > today) return 'future';
    if (dayIndex < currentStreak) return 'success';
    return 'missed';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-500 dark:bg-green-400';
      case 'missed':
        return 'bg-red-300 dark:bg-red-600';
      case 'future':
        return 'bg-gray-200 dark:bg-gray-700';
      default:
        return 'bg-gray-200 dark:bg-gray-700';
    }
  };

  return (
    <div className="p-6 rounded-xl bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/50">
      <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-6">
        365-Day Calendar
      </h3>
      <div className="grid grid-cols-15 sm:grid-cols-20 md:grid-cols-25 lg:grid-cols-30 gap-1">
        {Array.from({ length: daysInYear }, (_, index) => {
          const status = getDayStatus(index);
          return (
            <div
              key={index}
              className={`w-3 h-3 rounded-sm ${getStatusColor(status)} transition-all duration-200 hover:scale-125`}
              title={`Day ${index + 1}: ${status}`}
            />
          );
        })}
      </div>
      <div className="flex items-center justify-center space-x-6 mt-6 text-sm">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-sm bg-green-500"></div>
          <span className="text-gray-600 dark:text-gray-400">Success</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-sm bg-red-300 dark:bg-red-600"></div>
          <span className="text-gray-600 dark:text-gray-400">Reset</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-sm bg-gray-200 dark:bg-gray-700"></div>
          <span className="text-gray-600 dark:text-gray-400">Future</span>
        </div>
      </div>
    </div>
  );
}