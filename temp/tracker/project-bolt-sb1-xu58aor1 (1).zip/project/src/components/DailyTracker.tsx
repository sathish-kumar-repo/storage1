import React from 'react';
import { Check, X, Calendar, Flame, TrendingUp } from 'lucide-react';
import { TrackerData } from '../types';

interface DailyTrackerProps {
  trackerData: TrackerData;
  onUpdateDay: (date: string, success: boolean) => void;
}

export function DailyTracker({ trackerData, onUpdateDay }: DailyTrackerProps) {
  const today = new Date();
  const startDate = new Date(trackerData.startDate);
  
  // Generate calendar for current month
  const getCurrentMonthDays = () => {
    const year = today.getFullYear();
    const month = today.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const formatDate = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const getDayStatus = (date: Date) => {
    const dateStr = formatDate(date);
    
    // Before start date - disabled
    if (date < startDate) return 'before-start';
    
    // Future date - disabled
    if (date > today) return 'future';
    
    // Check if marked as success
    return trackerData.dailyChecks?.[dateStr] ? 'success' : 'failed';
  };

  const handleDayToggle = (date: Date) => {
    // Don't allow toggling future dates or dates before start
    if (date > today || date < startDate) return;
    
    const dateStr = formatDate(date);
    const currentStatus = trackerData.dailyChecks?.[dateStr] || false;
    onUpdateDay(dateStr, !currentStatus);
  };

  const monthDays = getCurrentMonthDays();
  const todayStr = formatDate(today);
  const todayStatus = getDayStatus(today);

  return (
    <div className="space-y-8">
      {/* Today's Check-in */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">Today's Check-in</h2>
            <p className="text-blue-100 mb-4">
              {today.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Flame className="w-5 h-5" />
                <span className="font-medium">Current Streak: {trackerData.currentStreak}</span>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5" />
                <span className="font-medium">Success Rate: {Math.round((trackerData.totalSuccessfulDays / Math.max(trackerData.totalDays, 1)) * 100)}%</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => handleDayToggle(today)}
            disabled={todayStatus === 'before-start'}
            className={`p-6 rounded-2xl transition-all duration-300 transform hover:scale-105 ${
              todayStatus === 'success'
                ? 'bg-green-500 hover:bg-green-600'
                : 'bg-white/20 hover:bg-white/30'
            } ${todayStatus === 'before-start' ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {todayStatus === 'success' ? (
              <Check className="w-8 h-8" />
            ) : (
              <Calendar className="w-8 h-8" />
            )}
          </button>
        </div>
      </div>

      {/* Monthly Calendar */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            {today.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </h3>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Journey started: {startDate.toLocaleDateString('en-US', { 
              month: 'short', 
              day: 'numeric', 
              year: 'numeric' 
            })}
          </div>
        </div>
        
        <div className="grid grid-cols-7 gap-2">
          {/* Day headers */}
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div key={day} className="text-center text-sm font-medium text-gray-500 dark:text-gray-400 py-3">
              {day}
            </div>
          ))}
          
          {/* Calendar days */}
          {monthDays.map((date, index) => {
            if (!date) {
              return <div key={`empty-${index}`} className="aspect-square" />;
            }
            
            const status = getDayStatus(date);
            const isToday = formatDate(date) === todayStr;
            const canToggle = status !== 'before-start' && status !== 'future';
            
            return (
              <button
                key={formatDate(date)}
                onClick={() => handleDayToggle(date)}
                disabled={!canToggle}
                className={`aspect-square rounded-xl flex items-center justify-center text-sm font-medium transition-all duration-200 hover:scale-105 relative ${
                  isToday ? 'ring-2 ring-blue-500 ring-offset-2 dark:ring-offset-gray-800' : ''
                } ${
                  status === 'success'
                    ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-900/50'
                    : status === 'failed'
                    ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-900/50'
                    : status === 'future'
                    ? 'bg-gray-100 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
                    : 'bg-gray-200 dark:bg-gray-600 text-gray-500 cursor-not-allowed'
                }`}
              >
                {status === 'success' ? (
                  <Check className="w-4 h-4" />
                ) : status === 'failed' ? (
                  <X className="w-4 h-4" />
                ) : (
                  date.getDate()
                )}
                {isToday && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full"></div>
                )}
              </button>
            );
          })}
        </div>
        
        <div className="flex items-center justify-center space-x-6 mt-6 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 rounded bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
              <Check className="w-3 h-3 text-green-700 dark:text-green-300" />
            </div>
            <span className="text-gray-600 dark:text-gray-400">Success</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 rounded bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
              <X className="w-3 h-3 text-red-700 dark:text-red-300" />
            </div>
            <span className="text-gray-600 dark:text-gray-400">Failed</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 rounded bg-gray-100 dark:bg-gray-700"></div>
            <span className="text-gray-600 dark:text-gray-400">Future/Disabled</span>
          </div>
        </div>
      </div>
    </div>
  );
}