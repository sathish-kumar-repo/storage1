import React from 'react';
import { AlertTriangle, ExternalLink } from 'lucide-react';

export function FirebaseSetup() {
  return (
    <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-6 mb-8">
      <div className="flex items-start space-x-3">
        <AlertTriangle className="w-6 h-6 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-amber-800 dark:text-amber-200 mb-2">
            Firebase Configuration Required
          </h3>
          <p className="text-amber-700 dark:text-amber-300 text-sm mb-4">
            To enable authentication and data syncing, you need to configure Firebase. Follow these steps:
          </p>
          <ol className="list-decimal list-inside space-y-2 text-sm text-amber-700 dark:text-amber-300 mb-4">
            <li>Go to the <a href="https://console.firebase.google.com" target="_blank" rel="noopener noreferrer" className="underline hover:text-amber-800 dark:hover:text-amber-200">Firebase Console</a></li>
            <li>Create a new project or select an existing one</li>
            <li>Enable Authentication with Email/Password and Google providers</li>
            <li>Create a Firestore database</li>
            <li>Get your Firebase configuration from Project Settings</li>
            <li>Update the configuration in <code className="bg-amber-100 dark:bg-amber-800 px-1 rounded">src/config/firebase.ts</code></li>
          </ol>
          <div className="flex items-center space-x-2">
            <ExternalLink className="w-4 h-4" />
            <a 
              href="https://firebase.google.com/docs/web/setup" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-amber-800 dark:text-amber-200 hover:underline text-sm font-medium"
            >
              Firebase Setup Documentation
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}