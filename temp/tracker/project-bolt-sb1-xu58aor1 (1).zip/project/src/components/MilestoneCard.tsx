import React from 'react';
import { Trophy, Lock } from 'lucide-react';
import { Milestone } from '../types';

interface MilestoneCardProps {
  milestone: Milestone;
  isNext?: boolean;
}

export function MilestoneCard({ milestone, isNext = false }: MilestoneCardProps) {
  return (
    <div className={`p-6 rounded-xl border transition-all duration-300 ${
      milestone.achieved
        ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
        : isNext
        ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
        : 'bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700'
    }`}>
      <div className="flex items-start space-x-4">
        <div className={`p-3 rounded-full ${
          milestone.achieved
            ? 'bg-green-100 dark:bg-green-800/30'
            : isNext
            ? 'bg-blue-100 dark:bg-blue-800/30'
            : 'bg-gray-100 dark:bg-gray-700/50'
        }`}>
          {milestone.achieved ? (
            <Trophy className={`w-6 h-6 text-green-600 dark:text-green-400`} />
          ) : (
            <Lock className={`w-6 h-6 ${
              isNext ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500'
            }`} />
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="font-bold text-gray-900 dark:text-gray-100">
              {milestone.title}
            </h3>
            <span className={`px-2 py-1 text-xs rounded-full ${
              milestone.achieved
                ? 'bg-green-100 dark:bg-green-800/30 text-green-700 dark:text-green-300'
                : isNext
                ? 'bg-blue-100 dark:bg-blue-800/30 text-blue-700 dark:text-blue-300'
                : 'bg-gray-100 dark:bg-gray-700/50 text-gray-600 dark:text-gray-400'
            }`}>
              Day {milestone.day}
            </span>
          </div>
          <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
            {milestone.description}
          </p>
          {milestone.achieved && milestone.achievedDate && (
            <p className="text-green-600 dark:text-green-400 text-xs mt-2">
              Achieved on {new Date(milestone.achievedDate).toLocaleDateString()}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}