export interface TrackerData {
  startDate: string;
  dailyChecks: Record<string, boolean>;
  currentStreak: number;
  longestStreak: number;
  totalResets: number;
  milestones: Milestone[];
  theme: 'light' | 'dark';
  totalSuccessfulDays: number;
  totalDays: number;
}

export interface Milestone {
  day: number;
  title: string;
  description: string;
  achieved: boolean;
  achievedDate?: string;
}

export interface Quote {
  text: string;
  author: string;
}

export interface DayData {
  date: string;
  success: boolean;
  dayNumber: number;
}

export interface ChartData {
  date: string;
  streak: number;
  success: number;
  week: string;
  month: string;
}