import React, { useState, useEffect } from 'react';
import { useTheme } from './hooks/useTheme';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useAuth } from './hooks/useAuth';
import { TrackerData } from './types';
import { defaultMilestones } from './data/milestones';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Dashboard } from './components/Dashboard';
import { DailyTracker } from './components/DailyTracker';
import { Analytics } from './components/Analytics';
import { MilestonesTab } from './components/MilestonesTab';
import { Settings } from './components/Settings';
import { AuthModal } from './components/AuthModal';

function App() {
  const { theme, toggleTheme } = useTheme();
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  const [trackerData, setTrackerData] = useLocalStorage<TrackerData>('nofab-tracker', {
    startDate: new Date().toISOString(),
    dailyChecks: {},
    currentStreak: 0,
    longestStreak: 0,
    totalResets: 0,
    milestones: defaultMilestones,
    theme: 'light',
    totalSuccessfulDays: 0,
    totalDays: 0
  });

  // Calculate streaks and stats
  useEffect(() => {
    const calculateStats = () => {
      const startDate = new Date(trackerData.startDate);
      const today = new Date();
      const totalDays = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      
      let currentStreak = 0;
      let longestStreak = 0;
      let tempStreak = 0;
      let successfulDays = 0;
      
      // Calculate from start date to today
      for (let d = new Date(startDate); d <= today; d.setDate(d.getDate() + 1)) {
        const dateStr = d.toISOString().split('T')[0];
        const isSuccess = trackerData.dailyChecks?.[dateStr] || false;
        
        if (isSuccess) {
          tempStreak++;
          successfulDays++;
          longestStreak = Math.max(longestStreak, tempStreak);
        } else {
          tempStreak = 0;
        }
      }
      
      // Current streak is the temp streak if it extends to today
      const todayStr = today.toISOString().split('T')[0];
      if (trackerData.dailyChecks?.[todayStr]) {
        currentStreak = tempStreak;
      } else {
        // Find the most recent streak
        let recentStreak = 0;
        for (let d = new Date(today); d >= startDate; d.setDate(d.getDate() - 1)) {
          const dateStr = d.toISOString().split('T')[0];
          if (trackerData.dailyChecks?.[dateStr]) {
            recentStreak++;
          } else {
            break;
          }
        }
        currentStreak = recentStreak;
      }
      
      return {
        currentStreak,
        longestStreak: Math.max(longestStreak, trackerData.longestStreak),
        totalSuccessfulDays: successfulDays,
        totalDays: Math.max(totalDays, 0)
      };
    };

    const stats = calculateStats();
    
    if (stats.currentStreak !== trackerData.currentStreak || 
        stats.longestStreak !== trackerData.longestStreak ||
        stats.totalSuccessfulDays !== trackerData.totalSuccessfulDays ||
        stats.totalDays !== trackerData.totalDays) {
      setTrackerData(prev => ({
        ...prev,
        ...stats
      }));
    }
  }, [trackerData.dailyChecks, trackerData.startDate, setTrackerData]);

  // Update milestones based on current streak
  useEffect(() => {
    const updatedMilestones = trackerData.milestones.map(milestone => {
      if (!milestone.achieved && trackerData.currentStreak >= milestone.day) {
        return {
          ...milestone,
          achieved: true,
          achievedDate: new Date().toISOString()
        };
      }
      return milestone;
    });

    const hasNewAchievements = updatedMilestones.some(
      (milestone, index) => milestone.achieved !== trackerData.milestones[index].achieved
    );

    if (hasNewAchievements) {
      setTrackerData(prev => ({
        ...prev,
        milestones: updatedMilestones
      }));
    }
  }, [trackerData.currentStreak, trackerData.milestones, setTrackerData]);

  const handleUpdateDay = (date: string, success: boolean) => {
    setTrackerData(prev => ({
      ...prev,
      dailyChecks: {
        ...prev.dailyChecks,
        [date]: success
      }
    }));
  };

  const handleReset = () => {
    setTrackerData(prev => ({
      ...prev,
      startDate: new Date().toISOString(),
      dailyChecks: {},
      currentStreak: 0,
      totalResets: prev.totalResets + 1,
      milestones: defaultMilestones,
      totalSuccessfulDays: 0,
      totalDays: 0
    }));
  };

  const handleImportData = (importedData: TrackerData) => {
    setTrackerData(importedData);
  };

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard trackerData={trackerData} />;
      case 'tracker':
        return <DailyTracker trackerData={trackerData} onUpdateDay={handleUpdateDay} />;
      case 'analytics':
        return <Analytics trackerData={trackerData} />;
      case 'milestones':
        return <MilestonesTab trackerData={trackerData} />;
      case 'settings':
        return <Settings trackerData={trackerData} onReset={handleReset} onImportData={handleImportData} />;
      default:
        return <Dashboard trackerData={trackerData} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-blue-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-blue-900 transition-all duration-500">
      <Navbar 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        theme={theme}
        onToggleTheme={toggleTheme}
        onShowAuth={() => setShowAuthModal(true)}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderActiveTab()}
      </main>
      
      <Footer />
      
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />
    </div>
  );
}

export default App;