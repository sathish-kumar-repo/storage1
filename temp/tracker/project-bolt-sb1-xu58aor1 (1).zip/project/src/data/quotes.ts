import { Quote } from '../types';

export const motivationalQuotes: Quote[] = [
  {
    text: "The strongest people are not those who show strength in front of us, but those who win battles we know nothing about.",
    author: "Unknown"
  },
  {
    text: "Every master was once a beginner. Every pro was once an amateur. Every success was once a failure.",
    author: "Robin Sharma"
  },
  {
    text: "The only impossible journey is the one you never begin.",
    author: "Tony Robbins"
  },
  {
    text: "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    author: "Winston Churchill"
  },
  {
    text: "Your current situation is not your final destination. The best is yet to come.",
    author: "Unknown"
  },
  {
    text: "The cave you fear to enter holds the treasure you seek.",
    author: "Joseph Campbell"
  },
  {
    text: "You are never too old to set another goal or to dream a new dream.",
    author: "C.S. Lewis"
  },
  {
    text: "The only way to do great work is to love what you do.",
    author: "Steve Jobs"
  }
];