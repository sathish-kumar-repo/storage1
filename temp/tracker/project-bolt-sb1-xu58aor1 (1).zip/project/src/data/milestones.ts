import { Milestone } from '../types';

export const defaultMilestones: Milestone[] = [
  {
    day: 1,
    title: "First Step",
    description: "You've taken the first step on your journey. Every expert was once a beginner.",
    achieved: false
  },
  {
    day: 7,
    title: "Week Warrior",
    description: "One week completed! You're building momentum and developing self-discipline.",
    achieved: false
  },
  {
    day: 30,
    title: "Month Master",
    description: "30 days of commitment! You're proving to yourself that change is possible.",
    achieved: false
  },
  {
    day: 60,
    title: "Double Down",
    description: "Two months strong! Your habits are becoming more natural.",
    achieved: false
  },
  {
    day: 90,
    title: "Quarter Champion",
    description: "90 days completed! This is a major milestone in forming lasting habits.",
    achieved: false
  },
  {
    day: 180,
    title: "Half Year Hero",
    description: "180 days of dedication! You've reached the halfway point to a full year.",
    achieved: false
  },
  {
    day: 365,
    title: "Year Conqueror",
    description: "365 days achieved! You've completed a full year of personal growth and discipline.",
    achieved: false
  }
];