import React from 'react';
import { Clock, TrendingUp, TrendingDown } from 'lucide-react';

interface Trade {
  id: string;
  asset: string;
  type: 'CALL' | 'PUT';
  amount: number;
  result: 'WIN' | 'LOSS';
  profit: number;
  time: string;
}

const mockTrades: Trade[] = [
  { id: '1', asset: 'EUR/USD', type: 'CALL', amount: 10, result: 'WIN', profit: 8.5, time: '14:32' },
  { id: '2', asset: 'GBP/USD', type: 'PUT', amount: 15, result: 'LOSS', profit: -15, time: '14:28' },
  { id: '3', asset: 'BTC/USD', type: 'CALL', amount: 20, result: 'WIN', profit: 17, time: '14:25' },
  { id: '4', asset: 'EUR/JPY', type: 'PUT', amount: 12, result: 'WIN', profit: 10.2, time: '14:22' },
  { id: '5', asset: 'USD/CAD', type: 'CALL', amount: 8, result: 'LOSS', profit: -8, time: '14:18' },
];

export const TradeHistory: React.FC = () => {
  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Clock className="w-5 h-5 text-blue-400" />
          <h3 className="text-white font-semibold">Recent Trades</h3>
        </div>
        <span className="text-gray-400 text-sm">Last 24 hours</span>
      </div>

      <div className="space-y-3">
        {mockTrades.map((trade) => (
          <div
            key={trade.id}
            className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-650 transition-colors"
          >
            <div className="flex items-center space-x-3">
              <div className={`p-2 rounded-lg ${
                trade.result === 'WIN' ? 'bg-green-900/30' : 'bg-red-900/30'
              }`}>
                {trade.type === 'CALL' ? (
                  <TrendingUp className={`w-4 h-4 ${
                    trade.result === 'WIN' ? 'text-green-400' : 'text-red-400'
                  }`} />
                ) : (
                  <TrendingDown className={`w-4 h-4 ${
                    trade.result === 'WIN' ? 'text-green-400' : 'text-red-400'
                  }`} />
                )}
              </div>
              <div>
                <p className="text-white font-medium">{trade.asset}</p>
                <p className="text-gray-400 text-sm">{trade.type} • ${trade.amount}</p>
              </div>
            </div>
            
            <div className="text-right">
              <p className={`font-medium ${
                trade.profit >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {trade.profit >= 0 ? '+' : ''}${trade.profit}
              </p>
              <p className="text-gray-400 text-sm">{trade.time}</p>
            </div>
          </div>
        ))}
      </div>
      
      <button className="w-full mt-4 p-3 bg-gray-700 hover:bg-gray-600 rounded-lg text-gray-300 text-sm transition-colors">
        View All Trades
      </button>
    </div>
  );
};