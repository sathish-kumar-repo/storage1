import React, { useState } from 'react';
import { Settings, Play, Pause, RotateCcw } from 'lucide-react';

export const BotSettings: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [settings, setSettings] = useState({
    tradeAmount: '10',
    riskLevel: '2',
    maxTrades: '20',
    stopLoss: '50',
    takeProfit: '100'
  });

  const handleSettingChange = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Settings className="w-5 h-5 text-blue-400" />
          <h3 className="text-white font-semibold">Bot Configuration</h3>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
              isRunning
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isRunning ? 'Stop Bot' : 'Start Bot'}</span>
          </button>
          <button className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors">
            <RotateCcw className="w-4 h-4 text-gray-400" />
          </button>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-gray-400 text-sm font-medium mb-2">
            Trade Amount ($)
          </label>
          <input
            type="number"
            value={settings.tradeAmount}
            onChange={(e) => handleSettingChange('tradeAmount', e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 text-sm font-medium mb-2">
            Risk Level (1-5)
          </label>
          <select
            value={settings.riskLevel}
            onChange={(e) => handleSettingChange('riskLevel', e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
          >
            <option value="1">1 - Conservative</option>
            <option value="2">2 - Low Risk</option>
            <option value="3">3 - Moderate</option>
            <option value="4">4 - Aggressive</option>
            <option value="5">5 - High Risk</option>
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-400 text-sm font-medium mb-2">
              Max Trades/Day
            </label>
            <input
              type="number"
              value={settings.maxTrades}
              onChange={(e) => handleSettingChange('maxTrades', e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-gray-400 text-sm font-medium mb-2">
              Stop Loss ($)
            </label>
            <input
              type="number"
              value={settings.stopLoss}
              onChange={(e) => handleSettingChange('stopLoss', e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-gray-400 text-sm font-medium mb-2">
            Take Profit ($)
          </label>
          <input
            type="number"
            value={settings.takeProfit}
            onChange={(e) => handleSettingChange('takeProfit', e.target.value)}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-blue-500 focus:outline-none"
          />
        </div>
      </div>

      <div className={`mt-4 p-3 rounded-lg border ${
        isRunning 
          ? 'bg-green-900/20 border-green-600' 
          : 'bg-gray-700 border-gray-600'
      }`}>
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${
            isRunning ? 'bg-green-400 animate-pulse' : 'bg-gray-400'
          }`} />
          <span className="text-sm text-gray-300">
            Bot Status: {isRunning ? 'Active' : 'Inactive'}
          </span>
        </div>
      </div>
    </div>
  );
};