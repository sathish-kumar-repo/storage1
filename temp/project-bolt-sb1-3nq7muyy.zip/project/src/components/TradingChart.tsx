import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface ChartProps {
  data: Array<{ time: string; value: number; profit: number }>;
  title: string;
}

export const TradingChart: React.FC<ChartProps> = ({ data, title }) => {
  const maxValue = Math.max(...data.map(d => d.value));
  const minValue = Math.min(...data.map(d => d.value));
  const range = maxValue - minValue;

  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-semibold">{title}</h3>
        <div className="flex items-center space-x-2">
          {data[data.length - 1]?.profit >= 0 ? (
            <TrendingUp className="w-4 h-4 text-green-400" />
          ) : (
            <TrendingDown className="w-4 h-4 text-red-400" />
          )}
          <span className={`text-sm font-medium ${
            data[data.length - 1]?.profit >= 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            {data[data.length - 1]?.profit >= 0 ? '+' : ''}
            {data[data.length - 1]?.profit.toFixed(2)}%
          </span>
        </div>
      </div>
      
      <div className="h-32 flex items-end space-x-1">
        {data.map((point, index) => {
          const height = range > 0 ? ((point.value - minValue) / range) * 100 : 50;
          const isProfit = point.profit >= 0;
          
          return (
            <div
              key={index}
              className="flex-1 flex flex-col items-center"
            >
              <div
                className={`w-full rounded-t transition-all duration-300 ${
                  isProfit ? 'bg-green-500' : 'bg-red-500'
                }`}
                style={{ height: `${Math.max(height, 5)}%` }}
              />
              <span className="text-xs text-gray-400 mt-1">{point.time}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};