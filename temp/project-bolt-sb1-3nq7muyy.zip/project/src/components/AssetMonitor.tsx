import React from 'react';
import { Activity, Eye, EyeOff } from 'lucide-react';

interface Asset {
  symbol: string;
  name: string;
  price: number;
  change: number;
  volume: string;
  active: boolean;
}

const mockAssets: Asset[] = [
  { symbol: 'EUR/USD', name: 'Euro/US Dollar', price: 1.0842, change: 0.12, volume: '2.4M', active: true },
  { symbol: 'GBP/USD', name: 'Pound/US Dollar', price: 1.2734, change: -0.08, volume: '1.8M', active: true },
  { symbol: 'BTC/USD', name: 'Bitcoin/US Dollar', price: 42350, change: 2.45, volume: '890K', active: false },
  { symbol: 'EUR/JPY', name: 'Euro/Japanese Yen', price: 159.82, change: 0.34, volume: '1.2M', active: true },
  { symbol: 'USD/CAD', name: 'US Dollar/Canadian Dollar', price: 1.3421, change: -0.15, volume: '980K', active: false },
];

export const AssetMonitor: React.FC = () => {
  return (
    <div className="bg-gray-800 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-blue-400" />
          <h3 className="text-white font-semibold">Asset Monitor</h3>
        </div>
        <button className="text-blue-400 hover:text-blue-300 text-sm font-medium">
          Manage Assets
        </button>
      </div>

      <div className="space-y-3">
        {mockAssets.map((asset) => (
          <div
            key={asset.symbol}
            className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-650 transition-colors"
          >
            <div className="flex items-center space-x-3">
              <button className="p-1">
                {asset.active ? (
                  <Eye className="w-4 h-4 text-blue-400" />
                ) : (
                  <EyeOff className="w-4 h-4 text-gray-400" />
                )}
              </button>
              <div>
                <p className="text-white font-medium">{asset.symbol}</p>
                <p className="text-gray-400 text-xs">{asset.name}</p>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-white font-medium">{asset.price.toLocaleString()}</p>
              <div className="flex items-center space-x-2">
                <span className={`text-sm font-medium ${
                  asset.change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {asset.change >= 0 ? '+' : ''}{asset.change}%
                </span>
                <span className="text-gray-400 text-xs">{asset.volume}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};