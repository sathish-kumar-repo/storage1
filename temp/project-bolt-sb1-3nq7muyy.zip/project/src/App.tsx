import React from 'react';
import { DollarSign, TrendingUp, Target, Zap, AlertTriangle } from 'lucide-react';
import { MetricCard } from './components/MetricCard';
import { TradingChart } from './components/TradingChart';
import { BotSettings } from './components/BotSettings';
import { TradeHistory } from './components/TradeHistory';
import { AssetMonitor } from './components/AssetMonitor';

// Mock data for charts
const profitData = Array.from({ length: 12 }, (_, i) => ({
  time: `${8 + i}:00`,
  value: 1000 + Math.random() * 500 - 250,
  profit: (Math.random() - 0.5) * 10
}));

const performanceData = Array.from({ length: 7 }, (_, i) => ({
  time: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
  value: 80 + Math.random() * 40,
  profit: (Math.random() - 0.3) * 15
}));

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-blue-600 rounded-lg p-2">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-white text-xl font-bold">QuotexBot Pro</h1>
              <p className="text-gray-400 text-sm">Automated Trading Dashboard</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="bg-red-900/20 border border-red-600 rounded-lg px-3 py-1">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span className="text-red-400 text-sm font-medium">DEMO MODE</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Disclaimer */}
        <div className="bg-yellow-900/20 border border-yellow-600 rounded-lg p-4 mb-6">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <p className="text-yellow-300 font-medium">Educational Demo Only</p>
          </div>
          <p className="text-yellow-200 text-sm mt-1">
            This is a demonstration interface for educational purposes. No real trading functionality is implemented. 
            Always consult financial professionals before making investment decisions.
          </p>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Total Balance"
            value="$2,847.50"
            change="12.4%"
            icon={DollarSign}
            positive={true}
          />
          <MetricCard
            title="Today's Profit"
            value="$156.80"
            change="8.2%"
            icon={TrendingUp}
            positive={true}
          />
          <MetricCard
            title="Win Rate"
            value="73.5%"
            change="2.1%"
            icon={Target}
            positive={true}
          />
          <MetricCard
            title="Active Trades"
            value="3"
            change="1"
            icon={Zap}
            positive={true}
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <TradingChart data={profitData} title="Profit/Loss Chart" />
          <TradingChart data={performanceData} title="Weekly Performance" />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Bot Settings */}
          <div className="lg:col-span-1">
            <BotSettings />
          </div>
          
          {/* Trade History */}
          <div className="lg:col-span-1">
            <TradeHistory />
          </div>
          
          {/* Asset Monitor */}
          <div className="lg:col-span-1">
            <AssetMonitor />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;