import { CandlestickData, StrengthAnalysis, ComparisonResult } from '../types';

export const calculateStrength = (candle: CandlestickData, includeVolume: boolean = false): StrengthAnalysis => {
  const { open, high, low, close, volume } = candle;
  
  const bodySize = Math.abs(close - open);
  const range = high - low;
  const bodyToRangeRatio = range > 0 ? bodySize / range : 0;
  
  const upperShadow = high - Math.max(open, close);
  const lowerShadow = Math.min(open, close) - low;
  
  // Volume strength calculation (if volume is provided)
  const volumeStrength = volume ? Math.log10(volume) / 10 : 0;
  
  // Overall strength calculation
  let overallStrength = (bodySize * 0.4) + (range * 0.3) + (bodyToRangeRatio * 0.2);
  
  if (includeVolume && volume) {
    overallStrength += volumeStrength * 0.1;
  }
  
  // Normalize strength to 0-100 scale
  overallStrength = Math.min(overallStrength * 1000, 100);
  
  const strengthRating = getStrengthRating(overallStrength);
  
  return {
    bodySize,
    range,
    bodyToRangeRatio,
    upperShadow,
    lowerShadow,
    volumeStrength: includeVolume ? volumeStrength : undefined,
    overallStrength,
    strengthRating
  };
};

const getStrengthRating = (strength: number): StrengthAnalysis['strengthRating'] => {
  if (strength >= 80) return 'Very Strong';
  if (strength >= 60) return 'Strong';
  if (strength >= 40) return 'Moderate';
  if (strength >= 20) return 'Weak';
  return 'Very Weak';
};

export const compareCandles = (candle1: CandlestickData, candle2: CandlestickData, includeVolume: boolean): ComparisonResult => {
  const candle1Analysis = calculateStrength(candle1, includeVolume);
  const candle2Analysis = calculateStrength(candle2, includeVolume);
  
  const strengthDifference = Math.abs(candle1Analysis.overallStrength - candle2Analysis.overallStrength);
  
  let winner: ComparisonResult['winner'] = 'tie';
  if (candle1Analysis.overallStrength > candle2Analysis.overallStrength) {
    winner = 1;
  } else if (candle2Analysis.overallStrength > candle1Analysis.overallStrength) {
    winner = 2;
  }
  
  return {
    winner,
    candle1Analysis,
    candle2Analysis,
    strengthDifference
  };
};

export const identifyPattern = (candle: CandlestickData): string => {
  const { open, high, low, close } = candle;
  const bodySize = Math.abs(close - open);
  const range = high - low;
  const bodyToRangeRatio = range > 0 ? bodySize / range : 0;
  
  const upperShadow = high - Math.max(open, close);
  const lowerShadow = Math.min(open, close) - low;
  
  const isBullish = close > open;
  const isBearish = close < open;
  const isDoji = bodySize < (range * 0.1);
  
  // Pattern identification logic
  if (isDoji) {
    if (upperShadow > bodySize * 3 && lowerShadow < bodySize) return 'Dragonfly Doji';
    if (lowerShadow > bodySize * 3 && upperShadow < bodySize) return 'Gravestone Doji';
    if (upperShadow > bodySize * 2 && lowerShadow > bodySize * 2) return 'Long-Legged Doji';
    return 'Doji';
  }
  
  if (bodyToRangeRatio > 0.7) {
    return isBullish ? 'Strong Bullish Marubozu' : 'Strong Bearish Marubozu';
  }
  
  if (bodyToRangeRatio > 0.5) {
    return isBullish ? 'Bullish Marubozu' : 'Bearish Marubozu';
  }
  
  if (upperShadow > bodySize * 2 && lowerShadow < bodySize * 0.5) {
    return isBullish ? 'Bullish Hammer' : 'Bearish Hanging Man';
  }
  
  if (lowerShadow > bodySize * 2 && upperShadow < bodySize * 0.5) {
    return isBullish ? 'Bullish Inverted Hammer' : 'Bearish Shooting Star';
  }
  
  if (bodyToRangeRatio < 0.3) {
    return 'Spinning Top';
  }
  
  return isBullish ? 'Bullish Candle' : 'Bearish Candle';
};

export const generateCandleId = (): string => {
  return `candle_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const formatPrice = (price: number): string => {
  return price.toFixed(5);
};