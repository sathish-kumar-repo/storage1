import React from 'react';
import { ComparisonResult } from '../types';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface ComparisonResultsProps {
  result: ComparisonResult;
}

const ComparisonResults: React.FC<ComparisonResultsProps> = ({ result }) => {
  const { winner, candle1Analysis, candle2Analysis, strengthDifference } = result;

  const getWinnerText = () => {
    if (winner === 'tie') return 'It\'s a Tie!';
    return `Candle ${winner} is Stronger`;
  };

  const getWinnerIcon = () => {
    if (winner === 'tie') return <Minus className="w-6 h-6 text-yellow-500" />;
    if (winner === 1) return <TrendingUp className="w-6 h-6 text-green-500" />;
    return <TrendingDown className="w-6 h-6 text-blue-500" />;
  };

  const getWinnerColor = () => {
    if (winner === 'tie') return 'text-yellow-600 dark:text-yellow-400';
    if (winner === 1) return 'text-green-600 dark:text-green-400';
    return 'text-blue-600 dark:text-blue-400';
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
      <div className="text-center mb-6">
        <div className="flex items-center justify-center space-x-2 mb-2">
          {getWinnerIcon()}
          <h2 className={`text-2xl font-bold ${getWinnerColor()}`}>
            {getWinnerText()}
          </h2>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          Strength difference: {strengthDifference.toFixed(2)} points
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Candle 1 Stats */}
        <div className={`p-4 rounded-lg ${winner === 1 ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800' : 'bg-gray-50 dark:bg-gray-700'}`}>
          <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Candle 1</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Strength:</span>
              <span className="font-medium">{candle1Analysis.overallStrength.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Rating:</span>
              <span className="font-medium">{candle1Analysis.strengthRating}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Body:</span>
              <span className="font-medium">{candle1Analysis.bodySize.toFixed(5)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Range:</span>
              <span className="font-medium">{candle1Analysis.range.toFixed(5)}</span>
            </div>
          </div>
        </div>

        {/* VS */}
        <div className="flex items-center justify-center">
          <div className="text-3xl font-bold text-gray-400 dark:text-gray-600">VS</div>
        </div>

        {/* Candle 2 Stats */}
        <div className={`p-4 rounded-lg ${winner === 2 ? 'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800' : 'bg-gray-50 dark:bg-gray-700'}`}>
          <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Candle 2</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Strength:</span>
              <span className="font-medium">{candle2Analysis.overallStrength.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Rating:</span>
              <span className="font-medium">{candle2Analysis.strengthRating}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Body:</span>
              <span className="font-medium">{candle2Analysis.bodySize.toFixed(5)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Range:</span>
              <span className="font-medium">{candle2Analysis.range.toFixed(5)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Analysis */}
      <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
        <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Analysis Breakdown</h4>
        <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
          <p>• Body Size contributes 40% to overall strength</p>
          <p>• Range (High-Low) contributes 30% to overall strength</p>
          <p>• Body-to-Range ratio contributes 20% to overall strength</p>
          {(candle1Analysis.volumeStrength !== undefined || candle2Analysis.volumeStrength !== undefined) && (
            <p>• Volume analysis contributes 10% to overall strength</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ComparisonResults;