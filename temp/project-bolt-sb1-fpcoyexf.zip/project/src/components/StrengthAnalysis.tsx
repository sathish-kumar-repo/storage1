import React from 'react';
import { StrengthAnalysis as StrengthAnalysisType } from '../types';

interface StrengthAnalysisProps {
  analysis: StrengthAnalysisType;
  candleNumber: 1 | 2;
  isWinner?: boolean;
}

const StrengthAnalysis: React.FC<StrengthAnalysisProps> = ({ analysis, candleNumber, isWinner }) => {
  const getStrengthColor = (rating: StrengthAnalysisType['strengthRating']) => {
    switch (rating) {
      case 'Very Strong': return 'text-green-700 dark:text-green-400';
      case 'Strong': return 'text-green-600 dark:text-green-500';
      case 'Moderate': return 'text-yellow-600 dark:text-yellow-400';
      case 'Weak': return 'text-orange-600 dark:text-orange-400';
      case 'Very Weak': return 'text-red-600 dark:text-red-400';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getProgressBarColor = (rating: StrengthAnalysisType['strengthRating']) => {
    switch (rating) {
      case 'Very Strong': return 'bg-green-500';
      case 'Strong': return 'bg-green-400';
      case 'Moderate': return 'bg-yellow-400';
      case 'Weak': return 'bg-orange-400';
      case 'Very Weak': return 'bg-red-400';
      default: return 'bg-gray-400';
    }
  };

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 ${
      isWinner ? 'ring-2 ring-yellow-400' : ''
    }`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Candle {candleNumber} Analysis
        </h3>
        {isWinner && (
          <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 rounded-full text-sm font-medium">
            🏆 Winner
          </span>
        )}
      </div>

      <div className="space-y-4">
        {/* Overall Strength */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Overall Strength
            </span>
            <span className={`text-sm font-bold ${getStrengthColor(analysis.strengthRating)}`}>
              {analysis.strengthRating}
            </span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-500 ${getProgressBarColor(analysis.strengthRating)}`}
              style={{ width: `${Math.min(analysis.overallStrength, 100)}%` }}
            />
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Score: {analysis.overallStrength.toFixed(2)}/100
          </div>
        </div>

        {/* Detailed Metrics */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Body Size:</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {analysis.bodySize.toFixed(5)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Range:</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {analysis.range.toFixed(5)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Body/Range:</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {(analysis.bodyToRangeRatio * 100).toFixed(1)}%
              </span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Upper Shadow:</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {analysis.upperShadow.toFixed(5)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-400">Lower Shadow:</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {analysis.lowerShadow.toFixed(5)}
              </span>
            </div>
            {analysis.volumeStrength !== undefined && (
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Volume Score:</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {analysis.volumeStrength.toFixed(2)}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StrengthAnalysis;