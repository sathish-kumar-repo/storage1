import React from 'react';
import { Settings as SettingsType } from '../types';
import { Settings as SettingsIcon, Moon, Sun, Volume2, VolumeX, Link, Unlink } from 'lucide-react';

interface SettingsProps {
  settings: SettingsType;
  onSettingsChange: (settings: SettingsType) => void;
  isOpen: boolean;
  onToggle: () => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, onSettingsChange, isOpen, onToggle }) => {
  const handleSettingChange = (key: keyof SettingsType, value: any) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  if (!isOpen) {
    return (
      <button
        onClick={onToggle}
        className="fixed top-4 right-4 p-3 bg-white dark:bg-gray-800 rounded-full shadow-lg border border-gray-200 dark:border-gray-700 hover:shadow-xl transition-all duration-200 z-50"
      >
        <SettingsIcon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full mx-4 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Settings</h2>
          <button
            onClick={onToggle}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <span className="text-xl">✕</span>
          </button>
        </div>

        <div className="space-y-6">
          {/* Dark Mode */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {settings.darkMode ? (
                <Moon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              ) : (
                <Sun className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              )}
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Dark Mode
              </span>
            </div>
            <button
              onClick={() => handleSettingChange('darkMode', !settings.darkMode)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.darkMode ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.darkMode ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Include Volume */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {settings.includeVolume ? (
                <Volume2 className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              ) : (
                <VolumeX className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              )}
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Include Volume in Analysis
              </span>
            </div>
            <button
              onClick={() => handleSettingChange('includeVolume', !settings.includeVolume)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.includeVolume ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.includeVolume ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Auto-link Candles */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {settings.autoLinkCandles ? (
                <Link className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              ) : (
                <Unlink className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              )}
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Auto-link Candles
              </span>
            </div>
            <button
              onClick={() => handleSettingChange('autoLinkCandles', !settings.autoLinkCandles)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.autoLinkCandles ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.autoLinkCandles ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Base Price */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Base Price
            </label>
            <input
              type="number"
              step="0.01"
              value={settings.basePrice}
              onChange={(e) => handleSettingChange('basePrice', parseFloat(e.target.value) || 100)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Used to quickly set all OHLC values to this base price
            </p>
          </div>
        </div>

        <div className="mt-6 text-xs text-gray-500 dark:text-gray-400">
          <p className="mb-1">
            <strong>Auto-link Candles:</strong> When enabled, Candle 2's open price automatically matches Candle 1's close price.
          </p>
          <p>
            <strong>Volume Analysis:</strong> Includes volume data in strength calculations for more accurate results.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Settings;