import React from 'react';
import { CandlestickData, Settings } from '../types';
import { identifyPattern, formatPrice } from '../utils/candlestickUtils';

interface CandleInputProps {
  candle: CandlestickData;
  onCandleChange: (candle: CandlestickData) => void;
  settings: Settings;
  candleNumber: 1 | 2;
  className?: string;
}

const CandleInput: React.FC<CandleInputProps> = ({
  candle,
  onCandleChange,
  settings,
  candleNumber,
  className = ''
}) => {
  const handleInputChange = (field: keyof CandlestickData, value: string) => {
    const numValue = parseFloat(value) || 0;
    onCandleChange({
      ...candle,
      [field]: numValue,
      name: identifyPattern({ ...candle, [field]: numValue })
    });
  };

  const applyBasePrice = () => {
    const basePrice = settings.basePrice;
    onCandleChange({
      ...candle,
      open: basePrice,
      high: basePrice,
      low: basePrice,
      close: basePrice,
      name: identifyPattern({
        ...candle,
        open: basePrice,
        high: basePrice,
        low: basePrice,
        close: basePrice
      })
    });
  };

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Candle {candleNumber}
        </h3>
        <button
          onClick={applyBasePrice}
          className="px-3 py-1 text-sm bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-md hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors"
        >
          Set Base ({settings.basePrice})
        </button>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Open
            </label>
            <input
              type="number"
              step="0.00001"
              value={candle.open}
              onChange={(e) => handleInputChange('open', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              High
            </label>
            <input
              type="number"
              step="0.00001"
              value={candle.high}
              onChange={(e) => handleInputChange('high', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Low
            </label>
            <input
              type="number"
              step="0.00001"
              value={candle.low}
              onChange={(e) => handleInputChange('low', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Close
            </label>
            <input
              type="number"
              step="0.00001"
              value={candle.close}
              onChange={(e) => handleInputChange('close', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        </div>

        {settings.includeVolume && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Volume
            </label>
            <input
              type="number"
              step="1"
              value={candle.volume || ''}
              onChange={(e) => handleInputChange('volume', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        )}

        <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Pattern: <span className="text-blue-600 dark:text-blue-400">{candle.name}</span>
          </div>
          <div className="text-xs text-gray-500 dark:text-gray-400">
            Body: {formatPrice(Math.abs(candle.close - candle.open))} | 
            Range: {formatPrice(candle.high - candle.low)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandleInput;