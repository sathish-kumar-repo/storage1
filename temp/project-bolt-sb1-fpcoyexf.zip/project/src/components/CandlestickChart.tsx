import React from 'react';
import { CandlestickData } from '../types';

interface CandlestickChartProps {
  candle: CandlestickData;
  isWinner?: boolean;
  className?: string;
}

const CandlestickChart: React.FC<CandlestickChartProps> = ({ candle, isWinner, className = '' }) => {
  const { open, high, low, close } = candle;
  const isBullish = close > open;
  
  // Calculate dimensions (scale for visual representation)
  const maxPrice = Math.max(open, high, low, close);
  const minPrice = Math.min(open, high, low, close);
  const priceRange = maxPrice - minPrice;
  const scaleFactor = priceRange > 0 ? 200 / priceRange : 1;
  
  // Calculate positions
  const bodyTop = Math.max(open, close);
  const bodyBottom = Math.min(open, close);
  const bodyHeight = Math.abs(close - open) * scaleFactor;
  const bodyY = (maxPrice - bodyTop) * scaleFactor + 20;
  
  // Wick calculations
  const upperWickY = (maxPrice - high) * scaleFactor + 20;
  const upperWickHeight = (high - bodyTop) * scaleFactor;
  const lowerWickY = (maxPrice - bodyBottom) * scaleFactor + 20;
  const lowerWickHeight = (bodyBottom - low) * scaleFactor;
  
  const candleColor = isBullish 
    ? 'text-green-500 dark:text-green-400' 
    : 'text-red-500 dark:text-red-400';
  
  const fillColor = isBullish ? 'fill-green-500 dark:fill-green-400' : 'fill-red-500 dark:fill-red-400';
  const strokeColor = isBullish ? 'stroke-green-600 dark:stroke-green-500' : 'stroke-red-600 dark:stroke-red-500';

  return (
    <div className={`flex flex-col items-center space-y-3 ${className}`}>
      {isWinner && (
        <div className="px-3 py-1 bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 rounded-full text-sm font-medium">
          🏆 Stronger
        </div>
      )}
      
      <div className={`relative border-2 rounded-lg p-4 transition-all duration-300 ${
        isWinner 
          ? 'border-yellow-400 bg-yellow-50 dark:bg-yellow-900/20 shadow-lg' 
          : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800'
      }`}>
        <svg width="60" height="240" className="mx-auto">
          {/* Upper wick */}
          {upperWickHeight > 0 && (
            <line
              x1="30"
              y1={upperWickY}
              x2="30"
              y2={upperWickY + upperWickHeight}
              className={`${strokeColor} stroke-2`}
            />
          )}
          
          {/* Candle body */}
          <rect
            x="20"
            y={bodyY}
            width="20"
            height={Math.max(bodyHeight, 2)}
            className={`${fillColor} ${strokeColor} stroke-1`}
            rx="1"
          />
          
          {/* Lower wick */}
          {lowerWickHeight > 0 && (
            <line
              x1="30"
              y1={lowerWickY}
              x2="30"
              y2={lowerWickY + lowerWickHeight}
              className={`${strokeColor} stroke-2`}
            />
          )}
          
          {/* Price labels */}
          <text x="45" y={upperWickY + 5} className="text-xs fill-gray-600 dark:fill-gray-400">
            {high.toFixed(5)}
          </text>
          <text x="45" y={lowerWickY + lowerWickHeight + 5} className="text-xs fill-gray-600 dark:fill-gray-400">
            {low.toFixed(5)}
          </text>
        </svg>
      </div>
      
      <div className="text-center space-y-1">
        <div className={`font-medium ${candleColor}`}>
          {isBullish ? '📈 Bullish' : '📉 Bearish'}
        </div>
        <div className="text-xs text-gray-600 dark:text-gray-400">
          Body: {Math.abs(close - open).toFixed(5)}
        </div>
        <div className="text-xs text-gray-600 dark:text-gray-400">
          Range: {(high - low).toFixed(5)}
        </div>
      </div>
    </div>
  );
};

export default CandlestickChart;