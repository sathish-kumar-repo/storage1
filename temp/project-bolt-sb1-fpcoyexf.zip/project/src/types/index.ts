export interface CandlestickData {
  id: string;
  name: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
  timestamp: number;
}

export interface StrengthAnalysis {
  bodySize: number;
  range: number;
  bodyToRangeRatio: number;
  upperShadow: number;
  lowerShadow: number;
  volumeStrength?: number;
  overallStrength: number;
  strengthRating: 'Very Weak' | 'Weak' | 'Moderate' | 'Strong' | 'Very Strong';
}

export interface Settings {
  darkMode: boolean;
  includeVolume: boolean;
  autoLinkCandles: boolean;
  basePrice: number;
}

export interface ComparisonResult {
  winner: 1 | 2 | 'tie';
  candle1Analysis: StrengthAnalysis;
  candle2Analysis: StrengthAnalysis;
  strengthDifference: number;
}