import React, { useState, useEffect } from 'react';
import { CandlestickData, Settings as SettingsType, ComparisonResult } from './types';
import { generateCandleId, identifyPattern, compareCandles } from './utils/candlestickUtils';
import { useLocalStorage } from './hooks/useLocalStorage';
import CandleInput from './components/CandleInput';
import CandlestickChart from './components/CandlestickChart';
import StrengthAnalysis from './components/StrengthAnalysis';
import ComparisonResults from './components/ComparisonResults';
import Settings from './components/Settings';
import { BarChart3, History, RefreshCw } from 'lucide-react';

function App() {
  // Default candle data
  const defaultCandle1: CandlestickData = {
    id: generateCandleId(),
    name: 'Doji',
    open: 106.374,
    high: 106.398,
    low: 106.371,
    close: 106.392,
    timestamp: Date.now()
  };

  const defaultCandle2: CandlestickData = {
    id: generateCandleId(),
    name: 'Bearish Candle',
    open: 106.392,
    high: 106.392,
    low: 106.379,
    close: 106.37902,
    timestamp: Date.now()
  };

  // State management
  const [candle1, setCandle1] = useState<CandlestickData>(defaultCandle1);
  const [candle2, setCandle2] = useState<CandlestickData>(defaultCandle2);
  const [settings, setSettings] = useLocalStorage<SettingsType>('candlestick-settings', {
    darkMode: window.matchMedia('(prefers-color-scheme: dark)').matches,
    includeVolume: false,
    autoLinkCandles: false,
    basePrice: 100
  });
  const [history, setHistory] = useLocalStorage<ComparisonResult[]>('candlestick-history', []);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Dark mode effect
  useEffect(() => {
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.darkMode]);

  // Auto-link candles effect
  useEffect(() => {
    if (settings.autoLinkCandles && candle1.close !== candle2.open) {
      setCandle2(prev => ({
        ...prev,
        open: candle1.close,
        name: identifyPattern({ ...prev, open: candle1.close })
      }));
    }
  }, [settings.autoLinkCandles, candle1.close]);

  // Calculate comparison
  const comparisonResult = compareCandles(candle1, candle2, settings.includeVolume);

  const handleCandle1Change = (newCandle: CandlestickData) => {
    setCandle1(newCandle);
  };

  const handleCandle2Change = (newCandle: CandlestickData) => {
    setCandle2(newCandle);
  };

  const handleSettingsChange = (newSettings: SettingsType) => {
    setSettings(newSettings);
  };

  const resetToDefaults = () => {
    setCandle1({ ...defaultCandle1, id: generateCandleId(), timestamp: Date.now() });
    setCandle2({ ...defaultCandle2, id: generateCandleId(), timestamp: Date.now() });
  };

  const saveToHistory = () => {
    const newHistory = [comparisonResult, ...history.slice(0, 9)]; // Keep last 10 entries
    setHistory(newHistory);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BarChart3 className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Candlestick Strength Analyzer
                </h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Compare and analyze candlestick patterns with precision
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors flex items-center space-x-2"
              >
                <History className="w-4 h-4" />
                <span>History</span>
              </button>
              <button
                onClick={resetToDefaults}
                className="px-4 py-2 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-lg hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors flex items-center space-x-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Reset</span>
              </button>
              <button
                onClick={saveToHistory}
                className="px-4 py-2 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 rounded-lg hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
              >
                Save Analysis
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Input Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <CandleInput
            candle={candle1}
            onCandleChange={handleCandle1Change}
            settings={settings}
            candleNumber={1}
          />
          <CandleInput
            candle={candle2}
            onCandleChange={handleCandle2Change}
            settings={settings}
            candleNumber={2}
          />
        </div>

        {/* Visual Comparison */}
        <div className="mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6 text-center">
              Visual Comparison
            </h2>
            <div className="flex justify-center items-end space-x-12">
              <CandlestickChart
                candle={candle1}
                isWinner={comparisonResult.winner === 1}
              />
              <CandlestickChart
                candle={candle2}
                isWinner={comparisonResult.winner === 2}
              />
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-8">
          <ComparisonResults result={comparisonResult} />
        </div>

        {/* Detailed Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <StrengthAnalysis
            analysis={comparisonResult.candle1Analysis}
            candleNumber={1}
            isWinner={comparisonResult.winner === 1}
          />
          <StrengthAnalysis
            analysis={comparisonResult.candle2Analysis}
            candleNumber={2}
            isWinner={comparisonResult.winner === 2}
          />
        </div>

        {/* History Modal */}
        {showHistory && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-4xl w-full mx-4 max-h-[80vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">Analysis History</h2>
                <button
                  onClick={() => setShowHistory(false)}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                >
                  <span className="text-xl">✕</span>
                </button>
              </div>
              <div className="space-y-4">
                {history.length === 0 ? (
                  <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                    No analysis history yet. Save an analysis to see it here.
                  </p>
                ) : (
                  history.map((result, index) => (
                    <div key={index} className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-gray-900 dark:text-white">
                          Analysis #{history.length - index}
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {result.winner === 'tie' ? 'Tie' : `Winner: Candle ${result.winner}`}
                        </span>
                      </div>
                      <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        Candle 1: {result.candle1Analysis.overallStrength.toFixed(2)} | 
                        Candle 2: {result.candle2Analysis.overallStrength.toFixed(2)} | 
                        Difference: {result.strengthDifference.toFixed(2)}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Settings */}
      <Settings
        settings={settings}
        onSettingsChange={handleSettingsChange}
        isOpen={settingsOpen}
        onToggle={() => setSettingsOpen(!settingsOpen)}
      />

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center text-sm text-gray-500 dark:text-gray-400">
            <p className="mb-2">
              Professional candlestick analysis tool with pattern recognition and strength comparison
            </p>
            <p>
              {settings.includeVolume ? 'Volume analysis enabled' : 'Volume analysis disabled'} | 
              {settings.autoLinkCandles ? ' Auto-linking enabled' : ' Auto-linking disabled'} | 
              Base price: {settings.basePrice}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;